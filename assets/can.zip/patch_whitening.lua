require 'hdf5'

file = hdf5.open('/share/bayes/yao/ILSVRC2012_img_train/trainData/train_patches.h5', 'r')

n = 1281167

mean = torch.zeros(1, 121):float()
cov  = torch.zeros(121, 121):float()

mean = torch.load('patch_mean.t7')
cov  = torch.load('patch_cov.t7')



