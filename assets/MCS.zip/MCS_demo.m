clear all
cd D:\Dropbox\MCS\
n = 200; m = 10;
loc2 = rand(n,2);
loc1 = zeros(n,2);

index = 0;
for i = 1:n
    if (0 < loc2(i,1) && loc2(i,1) < 0.5 && 0 < loc2(i,2) && loc2(i,2) < 0.5)
        index = index + 1;
        loc1(index,:) = loc2(i,:);        
    end    
end
loc1 = loc1(1:index,:);
loc2(:,1) = loc2(:,1) + 1;
% loc1 = rand(n,2);
TG1 = delaunay(loc1(:,1:2));
TG2 = delaunay(loc2(:,1:2));

tic
[tri_mat_g, tri_mat_G] = MCS_full(loc1',loc2',TG1',TG2'); 
toc

scrsz = get(0,'ScreenSize');
figure('Position',[400 100 scrsz(3)/2  scrsz(4)/1.5])

subplot(3,1,1), drawDelaunay(loc1,TG1);
subplot(3,1,1), drawDelaunay(loc2,TG2);
axis equal
axis([0,2,0,1]);
axis off

subplot(3,1,2), drawDelaunay(loc1,TG1);
subplot(3,1,2), drawMCS(loc1,tri_mat_g);
subplot(3,1,2), drawDelaunay(loc2,TG2);
subplot(3,1,2), drawMCS(loc2,tri_mat_G);
axis equal
axis([0,2,0,1]);
axis off


subplot(3,1,3), drawDelaunay(loc1,TG1);
subplot(3,1,3), drawMCS(loc1,tri_mat_g);
subplot(3,1,3), drawDelaunay(loc2,TG2);
subplot(3,1,3), drawMCS(loc2,tri_mat_G);
subplot(3,1,3), drawMatching(loc1,loc2,tri_mat_g,tri_mat_G);
axis equal
axis([0,2,0,1]);
axis off