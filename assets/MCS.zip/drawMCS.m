function drawMCS(loc,tri_mat)

for i = 1:length(tri_mat);
    a_x = loc(tri_mat(1,i),1);
    b_x = loc(tri_mat(2,i),1);
    c_x = loc(tri_mat(3,i),1);
    a_y = loc(tri_mat(1,i),2);
    b_y = loc(tri_mat(2,i),2);
    c_y = loc(tri_mat(3,i),2);
    patch([a_x,b_x,c_x],[a_y,b_y,c_y],'r');
end