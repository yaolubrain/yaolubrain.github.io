clear all
cd D:\Dropbox\MCS\

n = 100;
index = 1;

x = rand(n,2);
T = delaunay(x);
G = sign(delaunayGraph(x));

a = maximalCliques(G);