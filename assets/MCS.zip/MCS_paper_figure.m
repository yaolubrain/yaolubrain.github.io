clear all
cd D:\Dropbox\MCS\

n = 1000;
m = 50;
loc2 = rand(n,2);
median_num = median(loc2);
M = [2 1;1 2];
[a b] = knnsearch(loc2,median_num,'K',m,'Distance','mahalanobis','Cov',M);
loc1 = loc2(a,:);
loc2(:,1) = loc2(:,1) + 1;
TG1 = delaunay(loc1(:,1:2));
TG2 = delaunay(loc2(:,1:2));

tic
[tri_mat_g, tri_mat_G] = MCS_full(loc1',loc2',TG1',TG2'); 
toc
length(tri_mat_g)
scrsz = get(0,'ScreenSize');
figure('Position',[400 100 scrsz(3)/2  scrsz(4)/2.5])
drawDelaunay(loc1,TG1);
drawDelaunay(loc2,TG2);
axis equal
axis([0,2,0,1]);
axis off
set(gca, 'LooseInset', get(gca, 'TightInset'));

scrsz = get(0,'ScreenSize');
figure('Position',[400 100 scrsz(3)/2  scrsz(4)/2.5])
drawDelaunay(loc1,TG1);
drawMCS(loc1,tri_mat_g);
drawDelaunay(loc2,TG2);
drawMCS(loc2,tri_mat_G);
axis equal
axis([0,2,0,1]);
axis off
set(gca, 'LooseInset', get(gca, 'TightInset'));

scrsz = get(0,'ScreenSize');
figure('Position',[400 100 scrsz(3)/2  scrsz(4)/2.5])
drawDelaunay(loc1,TG1);
drawMCS(loc1,tri_mat_g);
drawDelaunay(loc2,TG2);
drawMCS(loc2,tri_mat_G);
drawMatching(loc1,loc2,tri_mat_g,tri_mat_G);
axis equal
axis([0,2,0,1]);
axis off
set(gca, 'LooseInset', get(gca, 'TightInset'));