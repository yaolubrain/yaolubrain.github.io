function drawMatching(loc1,loc2,tri_mat_g,tri_mat_G)

for i = 1:length(tri_mat_g);   
    p1_g = tri_mat_g(1,i);
    p1_G = tri_mat_G(1,i);
    p2_g = tri_mat_g(2,i);
    p2_G = tri_mat_G(2,i);
    p3_g = tri_mat_g(3,i);
    p3_G = tri_mat_G(3,i);
    line([loc1(p1_g,1) loc2(p1_G,1)], ...
         [loc1(p1_g,2) loc2(p1_G,2)], 'Color','b','LineWidth',0.1);     
    line([loc1(p2_g,1) loc2(p2_G,1)], ...
         [loc1(p2_g,2) loc2(p2_G,2)], 'Color','b','LineWidth',0.1);     
    line([loc1(p3_g,1) loc2(p3_G,1)], ...
         [loc1(p3_g,2) loc2(p3_G,2)], 'Color','b','LineWidth',0.1);          
end