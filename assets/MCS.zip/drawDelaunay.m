function drawDelaunay(loc,G)

for i=1:size(G,1)
    p1 = G(i,1);
    p2 = G(i,2);
    p3 = G(i,3);
    line([loc(p1,1) loc(p2,1)], ...
         [loc(p1,2) loc(p2,2)], 'Color', 'k','LineWidth',0.1);  
    line([loc(p2,1) loc(p3,1)], ...
         [loc(p2,2) loc(p3,2)], 'Color', 'k','LineWidth',0.1);  
    line([loc(p1,1) loc(p3,1)], ...
         [loc(p1,2) loc(p3,2)], 'Color', 'k','LineWidth',0.1);  
end