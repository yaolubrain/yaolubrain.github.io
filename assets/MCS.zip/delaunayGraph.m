function A=delaunayGraph(X)

T=delaunay(X);
A=zeros(length(X));

for i=1:length(T)
    for a=1:3;
        for b=1:3;
            A(T(i,a),T(i,b))=norm(X(T(i,a),:)-X(T(i,b),:));       
        end
    end
end

return