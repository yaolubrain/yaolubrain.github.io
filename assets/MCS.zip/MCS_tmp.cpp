void PushOneTri(int x_g, int y_g, int x_G, int y_G, 
                unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
                queue<Tri> &tri_queue_g, queue<Tri> &tri_queue_G,
                unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
                unordered_set<int> &tri_in_g, unordered_set<int> &tri_in_G,               
                vector<int> &node_order_g, vector<int> &node_order_G, int &node_order_iter, int n_g, int n_G)  
{
    int node_new_g = tri_mat_g[y_g*(n_g+1) + x_g];         
    if (node_new_g != 0 && tri_in_g.count(y_g*(n_g+1)*(n_g+1) + x_g*(n_g+1) + node_new_g))
            node_new_g = 0;                
    if (node_new_g == 0) {
        node_new_g = tri_mat_g[x_g*(n_g+1) + y_g];
        if (node_new_g != 0 && tri_in_g.count(x_g*(n_g+1)*(n_g+1) + y_g*(n_g+1) + node_new_g))
                node_new_g = 0;
    }
    
    int node_new_G = tri_mat_G[y_G*(n_G+1) + x_G];   
    if (node_new_G != 0 && tri_in_G.count(y_G*(n_G+1)*(n_G+1) + x_G*(n_G+1) + node_new_G))
            node_new_G = 0;                
    if (node_new_G == 0) {
        node_new_G = tri_mat_G[x_G*(n_G+1) + y_G];
        if (node_new_G != 0 && tri_in_G.count(x_G*(n_G+1)*(n_G+1) + y_G*(n_G+1) + node_new_G))
                node_new_G = 0;
    }
        
    if (node_new_g != 0 && node_new_G != 0) {        
        bool push_new_tri = false;
        if (node_order_g[node_new_g] == node_order_G[node_new_G]) {                                         
//             int node_next_1_g = tri_mat_g[node_new_g*(n_g+1) + x_g];
//             int node_next_2_g = tri_mat_g[node_new_g*(n_g+1) + y_g];
//             int node_next_1_G = tri_mat_G[node_new_G*(n_G+1) + x_G];
//             int node_next_2_G = tri_mat_G[node_new_G*(n_G+1) + y_G];
//             if (node_next_1_g == y_g)
//                 node_next_1_g = tri_mat_g[x_g*(n_g+1) + node_new_g];
//             if (node_next_2_g == x_g)
//                 node_next_2_g = tri_mat_g[y_g*(n_g+1) + node_new_g];            
//             if (node_next_1_G == y_G)
//                 node_next_1_G = tri_mat_G[x_G*(n_G+1) + node_new_G];
//             if (node_next_2_G == x_G)
//                 node_next_2_G = tri_mat_G[y_G*(n_G+1) + node_new_G];            
// 
//             if (node_order_g[node_next_1_g] == node_order_G[node_next_1_G] && 
//                 node_order_g[node_next_2_g] == node_order_G[node_next_2_G])
                push_new_tri = true;        
        }
        
        if (push_new_tri == true) {
            Tri tri_new_g;
            Tri tri_new_G;
            tri_new_g.a = node_new_g;
            tri_new_g.b = y_g;
            tri_new_g.c = x_g;        
            tri_new_G.a = node_new_G;
            tri_new_G.b = y_G;
            tri_new_G.c = x_G;        
                        
            tri_queue_g.push(tri_new_g);
            tri_queue_G.push(tri_new_G);        
            
            CountOneTri(tri_in_g, tri_new_g, n_g);      
            CountOneTri(tri_in_G, tri_new_G, n_G);                              
            
            tri_match_g.push_back(tri_new_g);
            tri_match_G.push_back(tri_new_G);
            
            CountOneTriMatched(tri_pair_matched, tri_new_g, tri_new_G, n_g, n_G);
            
            if (node_order_g[node_new_g] == 0 && node_order_G[node_new_G] == 0) {                    
                node_order_g[node_new_g] = node_order_iter;       
                node_order_G[node_new_G] = node_order_iter;                              
                node_order_iter++;
            }
        }
    }               
}


void MatchNode(vector<Tri> &tri_match_g_max, vector<Tri> &tri_match_G_max,
               const double *tri_list_g, const double *tri_list_G, 
               int n_g, int n_G, int l_g, int l_G)
{    
    unordered_map<int, int> tri_mat_g;
    unordered_map<int, int> tri_mat_G;
    BuildTriMat(tri_list_g, tri_mat_g, n_g, l_g);
    BuildTriMat(tri_list_G, tri_mat_G, n_G, l_G);        
    
    unordered_set<int> tri_pair_matched;
    
    int max_common_tri = 0;       
    int pos[6][3] = {{0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0}};    
    for (int k = 0; k < 6; k++) {
        for (int i = 0; i < l_g; i++) {
            Tri seed_g;
            seed_g.a = (int)tri_list_g[i*3 + pos[k][0]];       
            seed_g.b = (int)tri_list_g[i*3 + pos[k][1]];       
            seed_g.c = (int)tri_list_g[i*3 + pos[k][2]];                  
            for (int j = 0; j < l_G; j++) {
                Tri seed_G;
                seed_G.a = (int)tri_list_G[j*3];
                seed_G.b = (int)tri_list_G[j*3 + 1];        
                seed_G.c = (int)tri_list_G[j*3 + 2];                                 
//                 if (TriPairMatched(tri_pair_matched, seed_g, seed_G, n_g, n_G) == 0) {                          
                if (1) {      
                    vector<Tri> tri_match_g;
                    vector<Tri> tri_match_G;            
                    FindMatch(tri_pair_matched, tri_match_g, tri_match_G, tri_mat_g, tri_mat_G, seed_g, seed_G, n_g, n_G, l_g, l_G);              
                    if (tri_match_g.size() > max_common_tri) {                                
                        max_common_tri = (int)tri_match_g.size();         
                        tri_match_g_max = tri_match_g;
                        tri_match_G_max = tri_match_G;                                             
                    }                   
                }
            }
        }
    }                  
}

void PushOneTri(int x_g, int y_g, int x_G, int y_G, 
                unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
                queue<Tri> &tri_queue_g, queue<Tri> &tri_queue_G,
                unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
                unordered_set<int> &tri_in_g, unordered_set<int> &tri_in_G,               
                vector<int> &node_order_g, vector<int> &node_order_G, int &node_order_iter, int n_g, int n_G)  
{
    int node_new_g = tri_mat_g[y_g*(n_g+1) + x_g];         
    if (node_new_g != 0 && tri_in_g.count(y_g*(n_g+1)*(n_g+1) + x_g*(n_g+1) + node_new_g))
            node_new_g = 0;                
    if (node_new_g == 0) {
        node_new_g = tri_mat_g[x_g*(n_g+1) + y_g];
        if (node_new_g != 0 && tri_in_g.count(x_g*(n_g+1)*(n_g+1) + y_g*(n_g+1) + node_new_g))
                node_new_g = 0;
    }
    
    int node_new_G = tri_mat_G[y_G*(n_G+1) + x_G];   
    if (node_new_G != 0 && tri_in_G.count(y_G*(n_G+1)*(n_G+1) + x_G*(n_G+1) + node_new_G))
            node_new_G = 0;                
    if (node_new_G == 0) {
        node_new_G = tri_mat_G[x_G*(n_G+1) + y_G];
        if (node_new_G != 0 && tri_in_G.count(x_G*(n_G+1)*(n_G+1) + y_G*(n_G+1) + node_new_G))
                node_new_G = 0;
    }
        
    if (node_new_g != 0 && node_new_G != 0) {        
        bool push_new_tri = false;
        if (node_order_g[node_new_g] == node_order_G[node_new_G])                                         
                push_new_tri = true;                        
        if (push_new_tri) {
            Tri tri_new_g;
            Tri tri_new_G;
            tri_new_g.a = node_new_g;
            tri_new_g.b = y_g;
            tri_new_g.c = x_g;        
            tri_new_G.a = node_new_G;
            tri_new_G.b = y_G;
            tri_new_G.c = x_G;        
                        
            tri_queue_g.push(tri_new_g);
            tri_queue_G.push(tri_new_G);        
            
            CountOneTri(tri_in_g, tri_new_g, n_g);      
            CountOneTri(tri_in_G, tri_new_G, n_G);                              
            
            tri_match_g.push_back(tri_new_g);
            tri_match_G.push_back(tri_new_G);
            
//             CountOneTriMatched(tri_pair_matched, tri_new_g, tri_new_G, n_g, n_G);
            
            if (node_order_g[node_new_g] == 0 && node_order_G[node_new_G] == 0) {                    
                node_order_g[node_new_g] = node_order_iter;       
                node_order_G[node_new_G] = node_order_iter;                              
                node_order_iter++;
            }
        }
    }               
}
