#include <mex.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
using namespace std;

struct Tri {
    int a, b, c;
};

void BuildTriMat(const double *tri_list, unordered_map<int, int> &tri_mat, int n, int l)
{
     for (int i = 0; i < l; i++) {
         int a = (int)tri_list[i*3];
         int b = (int)tri_list[i*3 + 1];
         int c = (int)tri_list[i*3 + 2];
         if (tri_mat[a*(n+1) + b] == 0)
             tri_mat[a*(n+1) + b] = c;
         else if (tri_mat[b*(n+1) + a] == 0)
             tri_mat[b*(n+1) + a] = c;
         if (tri_mat[b*(n+1) + c] == 0)
             tri_mat[b*(n+1) + c] = a;
         else if (tri_mat[c*(n+1) + b] == 0)
             tri_mat[c*(n+1) + b] = a;
         if (tri_mat[a*(n+1) + c] == 0)
             tri_mat[a*(n+1) + c] = b;
         else if (tri_mat[c*(n+1) + a] == 0)
             tri_mat[c*(n+1) + a] = b;                          
     }              
}

void CountOneTri(unordered_set<int> &tri_in, Tri &tri_one, int n)
{
    tri_in.insert(tri_one.a*(n+1)*(n+1) + tri_one.b*(n+1) + tri_one.c);
    tri_in.insert(tri_one.a*(n+1)*(n+1) + tri_one.c*(n+1) + tri_one.b);
    tri_in.insert(tri_one.b*(n+1)*(n+1) + tri_one.a*(n+1) + tri_one.c);
    tri_in.insert(tri_one.b*(n+1)*(n+1) + tri_one.c*(n+1) + tri_one.a);
    tri_in.insert(tri_one.c*(n+1)*(n+1) + tri_one.a*(n+1) + tri_one.b);
    tri_in.insert(tri_one.c*(n+1)*(n+1) + tri_one.b*(n+1) + tri_one.a);
}

void CountOneTriMatched(unordered_set<int> &tri_pair_matched, Tri &tri_g, Tri &tri_G, int n_g, int n_G)
{    
    int N = (n_G+1)*(n_G+1)*(n_G+1);                   
    tri_pair_matched.insert(tri_g.a*(n_g+1)*(n_g+1)*N + tri_g.b*(n_g+1)*N + tri_g.c*N
                          + tri_G.a*(n_G+1)*(n_G+1)   + tri_G.b*(n_G+1)   + tri_G.c);
    tri_pair_matched.insert(tri_g.a*(n_g+1)*(n_g+1)*N + tri_g.c*(n_g+1)*N + tri_g.b*N
                          + tri_G.a*(n_G+1)*(n_G+1)   + tri_G.c*(n_G+1)   + tri_G.b);
    tri_pair_matched.insert(tri_g.b*(n_g+1)*(n_g+1)*N + tri_g.a*(n_g+1)*N + tri_g.c*N
                          + tri_G.b*(n_G+1)*(n_G+1)   + tri_G.a*(n_G+1)   + tri_G.c);        
    tri_pair_matched.insert(tri_g.b*(n_g+1)*(n_g+1)*N + tri_g.c*(n_g+1)*N + tri_g.a*N
                          + tri_G.b*(n_G+1)*(n_G+1)   + tri_G.c*(n_G+1)   + tri_G.a);        
    tri_pair_matched.insert(tri_g.c*(n_g+1)*(n_g+1)*N + tri_g.a*(n_g+1)*N + tri_g.b*N
                          + tri_G.c*(n_G+1)*(n_G+1)   + tri_G.a*(n_G+1)   + tri_G.b);        
    tri_pair_matched.insert(tri_g.c*(n_g+1)*(n_g+1)*N + tri_g.b*(n_g+1)*N + tri_g.a*N
                          + tri_G.c*(n_G+1)*(n_G+1)   + tri_G.b*(n_G+1)   + tri_G.a);        
}

size_t TriPairMatched(unordered_set<int> &tri_pair_matched, Tri &tri_g, Tri &tri_G, int n_g, int n_G)
{
    int N = (n_G+1)*(n_G+1)*(n_G+1);
    return tri_pair_matched.count(tri_g.a*(n_g+1)*(n_g+1)*N + tri_g.b*(n_g+1)*N + tri_g.c*N
                                + tri_G.a*(n_G+1)*(n_G+1)   + tri_G.b*(n_G+1)   + tri_G.c);
}

void PushOneTri(int x_g, int y_g, int x_G, int y_G, 
                unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
                queue<Tri> &tri_queue_g, queue<Tri> &tri_queue_G,
                unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
                unordered_set<int> &tri_in_g, unordered_set<int> &tri_in_G,               
                vector<int> &node_order_g, vector<int> &node_order_G, int &node_order_iter, int n_g, int n_G)  
{
    int node_new_g = tri_mat_g[y_g*(n_g+1) + x_g];         
    if (node_new_g != 0 && tri_in_g.count(y_g*(n_g+1)*(n_g+1) + x_g*(n_g+1) + node_new_g))
        node_new_g = 0;                
    if (node_new_g == 0) {
        node_new_g = tri_mat_g[x_g*(n_g+1) + y_g];
        if (node_new_g != 0 && tri_in_g.count(x_g*(n_g+1)*(n_g+1) + y_g*(n_g+1) + node_new_g))
                node_new_g = 0;
    }
    
    int node_new_G = tri_mat_G[y_G*(n_G+1) + x_G];   
    if (node_new_G != 0 && tri_in_G.count(y_G*(n_G+1)*(n_G+1) + x_G*(n_G+1) + node_new_G))
        node_new_G = 0;                
    if (node_new_G == 0) {
        node_new_G = tri_mat_G[x_G*(n_G+1) + y_G];
        if (node_new_G != 0 && tri_in_G.count(x_G*(n_G+1)*(n_G+1) + y_G*(n_G+1) + node_new_G))
                node_new_G = 0;
    }
        
    if (node_new_g != 0 && node_new_G != 0) {        
        bool push_new_tri = false;
        if (node_order_g[node_new_g] == node_order_G[node_new_G])                                         
            push_new_tri = true;                        
        if (push_new_tri) {
            Tri tri_new_g;
            Tri tri_new_G;
            tri_new_g.a = node_new_g;
            tri_new_g.b = y_g;
            tri_new_g.c = x_g;        
            tri_new_G.a = node_new_G;
            tri_new_G.b = y_G;
            tri_new_G.c = x_G;        
                        
            tri_queue_g.push(tri_new_g);
            tri_queue_G.push(tri_new_G);        
            
            CountOneTri(tri_in_g, tri_new_g, n_g);      
            CountOneTri(tri_in_G, tri_new_G, n_G);                              
            
            tri_match_g.push_back(tri_new_g);
            tri_match_G.push_back(tri_new_G);
            
            CountOneTriMatched(tri_pair_matched, tri_new_g, tri_new_G, n_g, n_G);
            
            if (node_order_g[node_new_g] == 0 && node_order_G[node_new_G] == 0) {                    
                node_order_g[node_new_g] = node_order_iter;       
                node_order_G[node_new_G] = node_order_iter;                              
                node_order_iter++;
            }
        }
    }               
}

void PushFirst3Tri(unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
                   queue<Tri> &tri_queue_g, queue<Tri> &tri_queue_G, Tri &seed_g, Tri &seed_G,
                   unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
                   unordered_set<int> &tri_in_g, unordered_set<int> &tri_in_G,                    
                   vector<int> &node_order_g, vector<int> &node_order_G, int &node_order_iter, int n_g, int n_G)  
{       
    // Generate a new triangle from Edge (b,a)
    PushOneTri(seed_g.b, seed_g.a, seed_G.b, seed_G.a, tri_pair_matched, tri_match_g, tri_match_G, 
               tri_queue_g, tri_queue_G, tri_mat_g, tri_mat_G, 
               tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);    
    // Generate a new triangle from Edge (a,c)      
    PushOneTri(seed_g.a, seed_g.c, seed_G.a, seed_G.c, tri_pair_matched, tri_match_g, tri_match_G, 
               tri_queue_g, tri_queue_G, tri_mat_g, tri_mat_G, 
               tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);    
    // Generate a new triangle from Edge (c,b)      
    PushOneTri(seed_g.c, seed_g.b, seed_G.c, seed_G.b, tri_pair_matched, tri_match_g, tri_match_G, 
               tri_queue_g, tri_queue_G, tri_mat_g, tri_mat_G, 
               tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);        
}

void PushTri(unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
             queue<Tri> &tri_queue_g, queue<Tri> &tri_queue_G, Tri &tri_one_g, Tri &tri_one_G, 
             unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
             unordered_set<int> &tri_in_g, unordered_set<int> &tri_in_G,              
             vector<int> &node_order_g, vector<int> &node_order_G, int &node_order_iter, int n_g, int n_G)  
{      
    // Generate a new triangle from Edge (b,a)        
    PushOneTri(tri_one_g.b, tri_one_g.a, tri_one_G.b, tri_one_G.a, tri_pair_matched, tri_match_g, tri_match_G, tri_queue_g, tri_queue_G, 
               tri_mat_g, tri_mat_G, tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);    
    // Generate a new triangle from Edge (a,c)    
    PushOneTri(tri_one_g.a, tri_one_g.c, tri_one_G.a, tri_one_G.c, tri_pair_matched, tri_match_g, tri_match_G, tri_queue_g, tri_queue_G, 
               tri_mat_g, tri_mat_G, tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);        
}

void FindMatch(unordered_set<int> &tri_pair_matched, vector<Tri> &tri_match_g, vector<Tri> &tri_match_G,
               unordered_map<int, int> &tri_mat_g, unordered_map<int, int> &tri_mat_G, 
               Tri &seed_g, Tri &seed_G, int n_g, int n_G, int l_g, int l_G)
{                
    vector<int> node_order_g(n_g + 1, 0);
    vector<int> node_order_G(n_G + 1, 0);  
    int node_order_iter = 1;
    node_order_g[seed_g.a] = node_order_iter;            
    node_order_G[seed_G.a] = node_order_iter;            
    node_order_iter++;
    node_order_g[seed_g.b] = node_order_iter;            
    node_order_G[seed_G.b] = node_order_iter;            
    node_order_iter++;
    node_order_g[seed_g.c] = node_order_iter;                                         
    node_order_G[seed_G.c] = node_order_iter;                                     
    node_order_iter++;
            
    unordered_set<int> tri_in_g;
    unordered_set<int> tri_in_G;
    CountOneTri(tri_in_g, seed_g, n_g);    
    CountOneTri(tri_in_G, seed_G, n_G);    
    
    CountOneTriMatched(tri_pair_matched, seed_g, seed_G, n_g, n_G);
    
    tri_match_g.push_back(seed_g);
    tri_match_G.push_back(seed_G);
      
    queue<Tri> tri_queue_g;
    queue<Tri> tri_queue_G;        
    PushFirst3Tri(tri_pair_matched, tri_match_g, tri_match_G, tri_queue_g, tri_queue_G, seed_g, seed_G, tri_mat_g, tri_mat_G, 
                  tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);        
        
    while (tri_queue_g.size() != 0) {        
        Tri tri_one_g = tri_queue_g.front();                
        Tri tri_one_G = tri_queue_G.front();                
        tri_queue_g.pop();                           
        tri_queue_G.pop();                         
        PushTri(tri_pair_matched, tri_match_g, tri_match_G, tri_queue_g, tri_queue_G, tri_one_g, tri_one_G, tri_mat_g, tri_mat_G, 
                tri_in_g, tri_in_G, node_order_g, node_order_G, node_order_iter, n_g, n_G);      
    }               
}

void MatchNode(vector<Tri> &tri_match_g_max, vector<Tri> &tri_match_G_max,
               const double *tri_list_g, const double *tri_list_G, 
               int n_g, int n_G, int l_g, int l_G)
{    
    unordered_map<int, int> tri_mat_g;
    unordered_map<int, int> tri_mat_G;
    BuildTriMat(tri_list_g, tri_mat_g, n_g, l_g);
    BuildTriMat(tri_list_G, tri_mat_G, n_G, l_G);        
    
    unordered_set<int> tri_pair_matched;
    
    int max_common_tri = 0;       
    int pos[6][3] = {{0,1,2}, {0,2,1}, {1,0,2}, {1,2,0}, {2,0,1}, {2,1,0}};    
    for (int k = 0; k < 6; k++) {
        for (int i = 0; i < l_g; i++) {
            Tri seed_g;
            seed_g.a = (int)tri_list_g[i*3 + pos[k][0]];       
            seed_g.b = (int)tri_list_g[i*3 + pos[k][1]];       
            seed_g.c = (int)tri_list_g[i*3 + pos[k][2]];                  
            for (int j = 0; j < l_G; j++) {
                Tri seed_G;
                seed_G.a = (int)tri_list_G[j*3];
                seed_G.b = (int)tri_list_G[j*3 + 1];        
                seed_G.c = (int)tri_list_G[j*3 + 2];                                 
                if (TriPairMatched(tri_pair_matched, seed_g, seed_G, n_g, n_G) == 0) {                                          
                    vector<Tri> tri_match_g;
                    vector<Tri> tri_match_G;            
                    FindMatch(tri_pair_matched, tri_match_g, tri_match_G, tri_mat_g, tri_mat_G, seed_g, seed_G, n_g, n_G, l_g, l_G);              
                    if (tri_match_g.size() > max_common_tri) {                                
                        max_common_tri = (int)tri_match_g.size();         
                        tri_match_g_max = tri_match_g;
                        tri_match_G_max = tri_match_G;                                             
                    }                   
                }
            }
        }
    }    
}

void mexFunction(int nlhs, mxArray *plhs[], 
                 int nrhs, mxArray *prhs[])
{
    const double *loc_g = mxGetPr(prhs[0]);    
    const double *loc_G = mxGetPr(prhs[1]);    
    const double *tri_list_g = mxGetPr(prhs[2]);    
    const double *tri_list_G = mxGetPr(prhs[3]);
        
    int n_g = (int)mxGetN(prhs[0]);
    int n_G = (int)mxGetN(prhs[1]);
    int l_g = (int)mxGetN(prhs[2]);    
    int l_G = (int)mxGetN(prhs[3]);           

    vector<Tri> tri_match_g_max;
    vector<Tri> tri_match_G_max;            
    MatchNode(tri_match_g_max, tri_match_G_max, tri_list_g, tri_list_G, n_g, n_G, l_g, l_G);            
    
    int m = (int)tri_match_g_max.size();
    double *tri_match_mat_g;
    double *tri_match_mat_G;
    plhs[0] = mxCreateDoubleMatrix(3, m, mxREAL);   
    plhs[1] = mxCreateDoubleMatrix(3, m, mxREAL);       
    tri_match_mat_g = mxGetPr(plhs[0]);
    tri_match_mat_G = mxGetPr(plhs[1]);       
    
    for (int i = 0; i < m; i++) {
        tri_match_mat_g[i*3]     = tri_match_g_max[i].a;
        tri_match_mat_g[i*3 + 1] = tri_match_g_max[i].b;
        tri_match_mat_g[i*3 + 2] = tri_match_g_max[i].c;
        tri_match_mat_G[i*3]     = tri_match_G_max[i].a;
        tri_match_mat_G[i*3 + 1] = tri_match_G_max[i].b;
        tri_match_mat_G[i*3 + 2] = tri_match_G_max[i].c;
    }            
}    