import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from torch.utils.data import DataLoader
from torch.autograd import Variable
from tqdm import tqdm

import argparse, os, sys, subprocess, math
import numpy as np
from glob import glob
from os.path import *
import time

import datasets
from utils import flow_utils, tools

from losses import *

import PWCNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-4, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')

args = parser.parse_args()


model = PWCNet.DevonPWC()
model.cuda()

crop_size = (384, 448)


#data_aug = transforms.Compose([transforms.ColorJitter(20, 0.5, 0.5, 0.2), \
#                               transforms.ToTensor() ])

data_path = 'data/FlyingChairs_release/data'
train_dataset = datasets.FlyingChairs(crop_size=(384,448), scale=20, root=data_path, transforms=data_aug)
train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)

optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0004)
scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[400000,600000,800000,1000000], gamma=0.5)

loss_F = PWCTrainLoss()

def train_epoch():
    model.train()
    total_error = 0
    progress = tqdm(tools.IteratorTimer(train_loader), ncols=100, total=len(train_loader))
    for i,v in enumerate(progress):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        output = model(torch.cat((input1, input2), 1))

        optimizer.zero_grad()
        loss = loss_F(output, target)
        loss.backward()
        optimizer.step()

        scheduler.step()

        total_error += loss.item()

    return total_error 

T = 420
prev_valid_loss = 0

fname = 'log/devon_pwc_train_lr_' + str(args.lr)
open(fname, 'w').close()

for t in range(T):

    train_loss = train_epoch()        
    
    printed_line = '{0:d} {1:3f}'.format(t, train_loss)
    print(printed_line)

    torch.save(model.state_dict(), 'devonpwc_chairs_' + str(args.lr) + '.pt')

    with open(fname, 'a') as f:
        f.write(printed_line + '\n')
