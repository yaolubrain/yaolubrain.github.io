import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

from PIL import Image

import datasets
from utils import flow_utils, tools


from losses import *

from siamese import Siamese
from devon import Devon
from devon_bn import DevonBN
from devon_mixed import DevonMixed
from devon_mixed_bn import DevonMixedBN
from devon_mixed_multi import DevonMixedMulti
from devon_mixed_0 import DevonMixed0
from devon_mixed_1 import DevonMixed1
from devon_mixed_2 import DevonMixed2

from devon_1 import Devon1
from devon_2 import Devon2
from warpnet import WarpNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()


model = None
if args.model == 'devon':
    model = Devon()
    model.load_state_dict(torch.load('models/devon_lr_0.001_decay_0.00001.pt'))
elif args.model == 'devon_nearest':
    model = DevonNearest()
elif args.model == 'devon_0':
    model = Devon0()
elif args.model == 'devon_1':
    model = Devon1()
elif args.model == 'devon_2':
    model = Devon2()
elif args.model == 'devon_mixed':
    model = DevonMixed()
#    model.load_state_dict(torch.load('models/devon_mixed_lr_1e-05_things_ft.pt'))
elif args.model == 'devon_mixed_2':
    model = DevonMixed2()
elif args.model == 'devon_mixed_1':
    model = DevonMixed1()
elif args.model == 'devon_mixed_0':
    model = DevonMixed0()
elif args.model == 'devon_mixed_bn':
    model = DevonMixedBN()
elif args.model == 'devon_bn':
    model = DevonBN()
elif args.model == 'devon_same_scale':
    model = DevonSameScale()
elif args.model == 'warpnet':
    model = WarpNet()
elif args.model == 'devon_readout':
    model = DevonReadout()
elif args.model == 'devon_multi_readout':
    model = DevonMultiReadout()
elif args.model == 'devon_mixed_multi':
    model = DevonMixedMulti()
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.0001_things_ft.pt'))
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_2.5e-05_things_ft.pt'))
    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_5e-05_things_ft.pt'))
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_1.25e-05_things_ft.pt'))
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.0001_ft.pt'))
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_1e-05_ft.pt'))
    #model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001_decay_0.00001.pt'))
    #model.load_state_dict(torch.load('models/devon_mixed_multi_lr_1e-05_things_ft.pt'))


model.cuda()
#model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_0_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_1e-05_ft.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_0_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_bn_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_small_lr_0.001.pt'))

para_num = 0
for p in model.parameters():
    para_num += p.nelement()
print(para_num)    


for param in model.parameters():
      param.requires_grad = False

upsample2 = nn.Upsample(scale_factor=2, mode='nearest')
upsample = nn.Upsample((436,1024), mode='bilinear')


args.crop_size = (384, 448)
args.inference_size = (384, 512)
data_path = '/home/yao/Code/data/MPI-Sintel-complete/training/'

train_dataset = datasets.MpiSintel(args, is_cropped=False, is_resized=True, root=data_path, dstype='clean')
#train_dataset = datasets.MpiSintel(args, is_cropped=False, is_resized=True, root=data_path, dstype='final')
train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False, num_workers=1, pin_memory=True)

total_time = 0

for i in range(100):
    input1 = torch.randn(1,3,112,256).cuda()
    input2 = torch.randn(1,3,112,256).cuda()

    input1 = Variable(input1, requires_grad=False)
    input2 = Variable(input2, requires_grad=False)

    tic = time.time()        
    output = model(input1, input2)
    torch.cuda.synchronize()
    toc = time.time()

    total_time += toc - tic




print(total_time / 100)

