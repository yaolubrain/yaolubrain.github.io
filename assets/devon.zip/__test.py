import numpy as np

import datasets
from utils import flow_utils, tools

F = flow_utils.readFlow('/home/yao/Code/data/FlyingChairs_release/data/00001_flow.flo')

print(F[:5,:5,:])
