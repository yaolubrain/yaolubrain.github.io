import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

from PIL import Image

import datasets
from utils import flow_utils, tools


from losses import *

from siamese import Siamese
from devon import Devon
from devon_bn import DevonBN
from devon_mixed import DevonMixed
from devon_mixed_bn import DevonMixedBN
from devon_mixed_multi import DevonMixedMulti
from devon_mixed_0 import DevonMixed0
from devon_mixed_1 import DevonMixed1
from devon_mixed_2 import DevonMixed2

from devon_1 import Devon1
from devon_2 import Devon2
from warpnet import WarpNet

from layers.resample2d_package.modules.resample2d import Resample2d


args = lambda : None
args.crop_size = (384, 448)
args.inference_size = (384, 512)
data_path = '/home/yao/Code/data/MPI-Sintel-complete/training/'

train_dataset = datasets.MpiSintel(args, is_cropped=False, is_resized=False, root=data_path, dstype='clean')
train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False, num_workers=1, pin_memory=True)

warp = Resample2d()

def valid():    
    total_error = 0
    total_time = 0
    for i,v in enumerate(train_loader):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        input1 = Variable(input1, requires_grad=False)
        input2 = Variable(input2, requires_grad=False)
        target = Variable(target, requires_grad=False)


        print(WarpLoss(input1, input2, target))
        print(LocalSmoothLoss(input1, 3))
        print(SegSmoothLoss(target, input1, 3))


err, time = valid()    

print(err, time)

