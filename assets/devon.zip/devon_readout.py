import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
from submodules import *

class DevonReadout(nn.Module):

    def __init__(self):
        super().__init__()
        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f2 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 1, 2, 2),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f3 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 1, 4, 4),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f4 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 1, 8, 8),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f5 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 1, 16, 16),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.g1 = readout()
        self.g2 = readout()
        self.g3 = readout()
        self.g4 = readout()
        self.g5 = readout()

        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')

        self.cv5 = CostVolumeL1(9,9,16,16)
        self.cv4 = DeformCostVolumeL1(9,9,8,8,False)
        self.cv3 = DeformCostVolumeL1(9,9,4,4,False)
        self.cv2 = DeformCostVolumeL1(9,9,2,2,False)
        self.cv1 = DeformCostVolumeL1(9,9,1,1,False)
        self.softmax2d = nn.Softmax2d()


    def forward(self, I, J):

        f1_I = self.f1(I)
        f2_I = self.f2(f1_I)
        f3_I = self.f3(f2_I)
        f4_I = self.f4(f3_I)
        f5_I = self.f5(f4_I)

        f1_J = self.f1(J)
        f2_J = self.f2(f1_J)
        f3_J = self.f3(f2_J)
        f4_J = self.f4(f3_J)
        f5_J = self.f5(f4_J)

        r5 = self.cv5(f5_I, f5_J)
        r5 = self.softmax2d(-r5)
        g5 = self.g5(r5)

        r4 = self.cv4(f4_I, f4_J, g5)
        r4 = self.softmax2d(-r4)
        g4 = g5 + self.g4(r4)

        r3 = self.cv3(f3_I, f3_J, g4)
        r3 = self.softmax2d(-r3)
        g3 = g4 + self.g3(r3)

        r2 = self.cv2(f2_I, f2_J, g3)
        r2 = self.softmax2d(-r2)
        g2 = g3 + self.g2(r2)

        r1 = self.cv1(f1_I, f1_J, g2)
        r1 = self.softmax2d(-r1)
        g1 = g2 + self.g1(r1)

        return g1, g2, g3, g4, g5
