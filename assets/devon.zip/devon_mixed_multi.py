import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
from submodules import *

class DevonMixedMulti(nn.Module):

    def __init__(self):
        super().__init__()

        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f2 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))

        self.f3 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))

        self.f4 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))

        self.g1 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,8,12,16),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.g2 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,8,12,16),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.g3 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,8,12,16),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.g4 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,8,12,16),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.upsample2 = nn.Upsample(scale_factor=2, mode='nearest')
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear')
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear')
        self.upsample16 = nn.Upsample(scale_factor=16, mode='bilinear')
        self.upsample32 = nn.Upsample(scale_factor=32, mode='bilinear')

        self.cv1 = CostVolumeL1(7,7,1,1)
        self.cv2 = CostVolumeL1(5,5,6,6)
        self.cv3 = CostVolumeL1(7,7,9,9)
        self.dcv1 = DeformCostVolumeL1(7,7,1,1,False)
        self.dcv2 = DeformCostVolumeL1(5,5,6,6,False)
        self.dcv3 = DeformCostVolumeL1(7,7,9,9,False)
        self.softmax2d = nn.Softmax2d()

    def forward(self, I, J):

        f1_I = self.f1(I)
        f2_I = self.f2(I)
        f3_I = self.f3(I)
        f4_I = self.f4(I)

        f1_J = self.f1(J)
        f2_J = self.f2(J)
        f3_J = self.f3(J)
        f4_J = self.f4(J)

        r4_1 = self.cv1(f4_I, f4_J)
        r4_2 = self.cv2(f4_I, f4_J)
        r4_3 = self.cv3(f4_I, f4_J)
        r4 = torch.cat((r4_1, r4_2, r4_3), dim=1)
        r4 = torch.exp(-r4)
        g4 = self.g4(r4)
        g4_up = 2*self.upsample2(g4)
        g4_out = 32*self.upsample32(g4)

        r3_1 = self.dcv1(f3_I, f3_J, g4_up)
        r3_2 = self.dcv2(f3_I, f3_J, g4_up)
        r3_3 = self.dcv3(f3_I, f3_J, g4_up)
        r3 = torch.cat((r3_1, r3_2, r3_3), dim=1)
        r3 = torch.exp(-r3)
        g3 = self.g3(r3) + g4_up
        g3_up = 2*self.upsample2(g3)
        g3_out = 16*self.upsample16(g3)

        r2_1 = self.dcv1(f2_I, f2_J, g3_up)
        r2_2 = self.dcv2(f2_I, f2_J, g3_up)
        r2_3 = self.dcv3(f2_I, f2_J, g3_up)
        r2 = torch.cat((r2_1, r2_2, r2_3), dim=1)
        r2 = torch.exp(-r2)
        g2 = self.g2(r2) + g3_up
        g2_up = 2*self.upsample2(g2)
        g2_out = 8*self.upsample8(g2)

        r1_1 = self.dcv1(f1_I, f1_J, g2_up)
        r1_2 = self.dcv2(f1_I, f1_J, g2_up)
        r1_3 = self.dcv3(f1_I, f1_J, g2_up)
        r1 = torch.cat((r1_1, r1_2, r1_3), dim=1)
        r1 = torch.exp(-r1)
        g1 = self.g1(r1) + g2_up
        g1_out = 4*self.upsample4(g1)

        return g1_out, g2_out, g3_out, g4_out
