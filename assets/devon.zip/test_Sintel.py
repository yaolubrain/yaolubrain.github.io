import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

from PIL import Image

import datasets
from utils import flow_utils, tools

from losses import *

import PWCNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()

model = None
if args.model == 'devon':
    model = PWCNet.DevonPWC()
    model.load_state_dict(torch.load('models/devon5_chairs.pt'))
else:
    model = PWCNet.PWCDCNet()
    model.load_state_dict(torch.load('pwc_chairs.pt'))
model.cuda()
print('using model: ' + args.model)

num = 0
for param in model.parameters():
      param.requires_grad = False
      num += param.numel()

print(num)      

upsample4 = nn.Upsample(scale_factor=4, mode='bilinear')
upsample = nn.Upsample((436,1024), mode='bilinear')

args.crop_size = (384, 448)
args.inference_size = (384, 512)
data_path = '/flush1/lu033/MPI-Sintel-complete/training'

train_dataset = datasets.MpiSintel(args, is_cropped=False, is_resized=True, root=data_path, dstype='clean')
#train_dataset = datasets.MpiSintel(args, is_cropped=False, is_resized=True, root=data_path, dstype='final')
train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False, num_workers=1, pin_memory=True)

def valid():    
    model.eval()
    total_error = 0
    total_time = 0
    for i,v in enumerate(train_loader):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        tic = time.time()        
        output = model(torch.cat((input1, input2), 1))
        output = 1*upsample(output)
        torch.cuda.synchronize()
        toc = time.time()
        print(output.abs().mean())
        print(target.abs().mean())

#        print(toc - tic)

        total_time += toc - tic

        output.data[:,1,:,:] *= 436 / 448

        epe = EPE(output, target).data[0]
        total_error += epe
        print(i, epe)

    return total_error / len(train_dataset), total_time / len(train_dataset)

err, time = valid()    

print(err, time)
