import torch
import torch.nn as nn

class Siamese(nn.Module):

    def __init__(self):
        super().__init__()
        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))
       
        self.f2 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.f3 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.f4 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.g1 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g2 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g3 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g4 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear')


    def forward(self, I, J):

        f1_I = self.f1(I)
        f2_I = self.f2(f1_I)
        f3_I = self.f3(f2_I)
        f4_I = self.f4(f3_I)

        f1_J = self.f1(J)
        f2_J = self.f2(f1_J)
        f3_J = self.f3(f2_J)
        f4_J = self.f4(f3_J)

        r1 = torch.cat((f1_I, f1_J), dim=1)
        r2 = torch.cat((f2_I, f2_J), dim=1)
        r3 = torch.cat((f3_I, f3_J), dim=1)
        r4 = torch.cat((f4_I, f4_J), dim=1)

        g4 = self.g4(r4)
        g3 = self.upsample(g4) + self.g3(r3)
        g2 = self.upsample(g3) + self.g2(r2)
        g1 = self.upsample(g2) + self.g1(r1)


        return g1, g2, g3, g4
class FlowNet(nn.Module):

    def __init__(self):
        super().__init__()
        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))
       
        self.f2 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.f3 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.f4 = nn.Sequential(
                      nn.Conv2d(16, 16, 3, 2, 1),
                      nn.LeakyReLU(0.1,True),
                      nn.Conv2d(16, 16, 3, 1, 1),
                      nn.LeakyReLU(0.1,True))

        self.g1 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g2 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g3 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.g4 = nn.Sequential(
                    nn.Conv2d(32, 32, 3, 1, 1),
                    nn.LeakyReLU(0.1,True),
                    nn.Conv2d(32, 2, 3, 1, 1))

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear')


    def forward(self, I, J):

        f1_I = self.f1(I)
        f2_I = self.f2(f1_I)
        f3_I = self.f3(f2_I)
        f4_I = self.f4(f3_I)

        f1_J = self.f1(J)
        f2_J = self.f2(f1_J)
        f3_J = self.f3(f2_J)
        f4_J = self.f4(f3_J)

        r1 = torch.cat((f1_I, f1_J), dim=1)
        r2 = torch.cat((f2_I, f2_J), dim=1)
        r3 = torch.cat((f3_I, f3_J), dim=1)
        r4 = torch.cat((f4_I, f4_J), dim=1)

        g4 = self.g4(r4)
        g3 = self.upsample(g4) + self.g3(r3)
        g2 = self.upsample(g3) + self.g2(r2)
        g1 = self.upsample(g2) + self.g1(r1)


        return g1, g2, g3, g4

