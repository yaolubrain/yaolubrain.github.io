import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
from submodules import *

class DevonBN(nn.Module):

    def __init__(self):
        super().__init__()
        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 16, 3, 2, 1),
                      nn.BatchNorm2d(16),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(16, 32, 3, 1, 1),
                      nn.BatchNorm2d(32),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.BatchNorm2d(32),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 1, 1),
                      nn.BatchNorm2d(32),
                      nn.LeakyReLU(0.1, True))

        self.f2 = nn.Sequential(
                      nn.Conv2d(32, 64, 3, 2, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True))

        self.f3 = nn.Sequential(
                      nn.Conv2d(64, 96, 3, 2, 1),
                      nn.BatchNorm2d(96),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(96, 96, 3, 1, 1),
                      nn.BatchNorm2d(96),
                      nn.LeakyReLU(0.1, True))

        self.f4 = nn.Sequential(
                      nn.Conv2d(96, 128, 3, 2, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True))

        self.f5 = nn.Sequential(
                      nn.Conv2d(128, 192, 3, 2, 1),
                      nn.BatchNorm2d(192),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(192, 192, 3, 1, 1),
                      nn.BatchNorm2d(192),
                      nn.LeakyReLU(0.1, True))

        self.g1 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      ResBlockBN(128,1,2,3,4),
                      ResBlockBN(128,1,4,6,8),
                      ResBlockBN(128,1,6,9,12),
                      ResBlockBN(128,1,8,12,16),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 2, 3, 1, 1))

        self.g2 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      ResBlockBN(128,1,2,3,4),
                      ResBlockBN(128,1,4,6,8),
                      ResBlockBN(128,1,6,9,12),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 2, 3, 1, 1))

        self.g3 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      ResBlockBN(128,1,2,3,4),
                      ResBlockBN(128,1,4,6,8),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 2, 3, 1, 1))

        self.g4 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      ResBlockBN(128,1,2,3,4),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 2, 3, 1, 1))

        self.g5 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.BatchNorm2d(128),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.BatchNorm2d(64),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 2, 3, 1, 1))

        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')

        self.cv = CostVolumeL1(9,9,1,1)
        self.dcv = DeformCostVolumeL1(9,9,1,1,False)
        self.softmax2d = nn.Softmax2d()


    def forward(self, I, J):

        f1_I = self.f1(I)
        f2_I = self.f2(f1_I)
        f3_I = self.f3(f2_I)
        f4_I = self.f4(f3_I)
        f5_I = self.f5(f4_I)

        f1_J = self.f1(J)
        f2_J = self.f2(f1_J)
        f3_J = self.f3(f2_J)
        f4_J = self.f4(f3_J)
        f5_J = self.f5(f4_J)

        r5 = self.cv(f5_I, f5_J)
        r5 = self.softmax2d(-r5)
        g5 = self.g5(r5)
        g5_up = self.upsample(g5)

        r4 = self.dcv(f4_I, f4_J, 1/32*g5_up)
        r4 = self.softmax2d(-r4)
        g4 = g5_up + self.g4(r4)
        g4_up = self.upsample(g4)

        r3 = self.dcv(f3_I, f3_J, 1/16*g4_up)
        r3 = self.softmax2d(-r3)
        g3 = g4_up + self.g3(r3)
        g3_up = self.upsample(g3)

        r2 = self.dcv(f2_I, f2_J, 1/8*g3_up)
        r2 = self.softmax2d(-r2)
        g2 = g3_up + self.g2(r2)
        g2_up = self.upsample(g2)

        r1 = self.dcv(f1_I, f1_J, 1/4*g2_up)
        r1 = self.softmax2d(-r1)
        g1 = g2_up + self.g1(r1)

        return g1, g2, g3, g4, g5
