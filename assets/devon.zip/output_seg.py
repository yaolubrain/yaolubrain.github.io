import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time
from PIL import Image

import datasets
from utils import flow_utils, tools
import pylab as plt



from losses import *

from siamese import Siamese
from devon import Devon
from devon_1 import Devon1
from devon_bn import DevonBN
from devon_same_scale import DevonSameScale
from devon_mixed import DevonMixed
from warpnet import WarpNet
from devon_small import DevonSmall

from devon_mixed_multi import DevonMixedMulti
from segnet import SegNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()


model = SegNet().cuda()
#model.load_state_dict(torch.load('models/segnet_smo_loss_5x5.pt'))
model.load_state_dict(torch.load('models/segnet_lr_0.0001.pt'))
#model.load_state_dict(torch.load('models/segnet_edge.pt'))
#model.load_state_dict(torch.load('models/segnet_lr_0.001_5x5_10_dim_out.pt'))
#model.load_state_dict(torch.load('models/segnet_lr_0.001_motion_boundry.pt'))

img1 = Image.open('/home/yao/Code/data/eval-data/Army/frame10.png')
img2 = Image.open('/home/yao/Code/data/eval-data/Army/frame11.png')
img1 = Image.open('/home/yao/Code/data/FlyingChairs_release/data/00003_img1.ppm')
img2 = Image.open('/home/yao/Code/data/FlyingChairs_release/data/00043_img2.ppm')
img1 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/clean/temple_2/frame_0013.png')
img1 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/clean/bamboo_2/frame_0033.png')
#img1 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/clean/alley_1/frame_0013.png')
img2 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/clean/bamboo_2/frame_0014.png')
#img1 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_10.png')
#img2 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_11.png')


#flow = frame_utils.read_gen('/home/yao/Code/data/FlyingChairs_release/data/00043_flow.flo')
#img1 = img1.resize((1024, 448), Image.ANTIALIAS)
#img2 = img2.resize((1024, 448), Image.ANTIALIAS)
img1 = img1.resize((1056, 384), Image.ANTIALIAS)
img2 = img2.resize((1056, 384), Image.ANTIALIAS)
#img1 = img1.resize((512//4, 384//4), Image.ANTIALIAS)
#img2 = img2.resize((512//4, 384//4), Image.ANTIALIAS)


I = img1


img1 = np.array(img1).transpose(2,0,1)
img2 = np.array(img2).transpose(2,0,1)
img1 = torch.from_numpy(img1.astype(np.float32)).clone()
img2 = torch.from_numpy(img2.astype(np.float32)).clone()

h = img1.size()[1]
w = img1.size()[2]

img1 = img1.view(1,3,h,w).clone()
img2 = img2.view(1,3,h,w).clone()

img1.mul_(2/255)
img2.mul_(2/255)
img1.add_(-1)
img2.add_(-1)

#img1[:,:,100:200,100:200].fill_(1)


input1 = img1.cuda()

print(input1.size())

input1 = Variable(input1)

output = model(input1) 

cv = CostVolumeL1(3,3,1,1)

output = torch.exp(-cv(output, output) * 1)
#output = output.round()
print(output)
output = output.sum(1)
#v, output = output.max(1)
#output = output[0].round()
#output = torch.le(output, 0.9)
#output = output.sum(1)
#entro = - output * torch.log(output)
#entro = entro.sum(1)
#output = entro

output = output.data[0].cpu().numpy()



f, (ax1, ax2) = plt.subplots(1, 2)
ax1.imshow(I)
ax2.imshow(output, cmap='hot')

plt.show()
