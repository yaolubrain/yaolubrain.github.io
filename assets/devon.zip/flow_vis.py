import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time
from PIL import Image

import datasets
from utils import flow_utils, tools
import pylab as plt

from losses import *
from layers.cost_volume_package.modules.cost_volume import *

from siamese import Siamese
from devon import Devon
from devon_1 import Devon1
from devon_bn import DevonBN
from devon_same_scale import DevonSameScale
from devon_mixed import DevonMixed
from warpnet import WarpNet
from devon_small import DevonSmall

from devon_mixed_multi import DevonMixedMulti
from segnet import SegNet
import utils.frame_utils as frame_utils
import utils.flow_utils as flow_utils

import cv2

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()


model = CostVolumeL1(3,3,1,1).cuda()
#model.load_state_dict(torch.load('models/segnet_lr_0.001_5x5_10_dim_out.pt'))
#model.load_state_dict(torch.load('models/segnet_lr_0.001_motion_boundry.pt'))

#img1 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/final/alley_1/frame_0013.png')
#img2 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/final/alley_1/frame_0014.png')
#img1 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_10.png')
#img2 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_11.png')

index = 3

#flo_fname = '/home/yao/Code/data/FlyingChairs_release/data/%05d_flow.flo' % index
#img_fname = '/home/yao/Code/data/FlyingChairs_release/data/%05d_img1.ppm' % index

flo_fname = '/home/yao/Code/data/MPI-Sintel-complete/training/flow/bamboo_2/frame_0023.flo'
img_fname = '/home/yao/Code/data/MPI-Sintel-complete/training/final/bamboo_2/frame_0023.png'
flow = frame_utils.read_gen(flo_fname)

img1 = Image.open(img_fname)
I = img1


img1 = np.array(img1).transpose(2,0,1)
img1 = torch.from_numpy(img1.astype(np.float32)).clone()

h = img1.size()[1]
w = img1.size()[2]

img1 = img1.view(1,3,h,w).clone()

img1.mul_(2/255)
img1.add_(-1)

flow = flow.transpose(2,0,1)
input1 = torch.Tensor(flow).cuda().view(1, 2, h, w)


input1 = Variable(input1)

output = model(input1, input1)
output = torch.exp(-output)
#output = torch.le(output,1).float()
output = output.sum(1)
#v, output = output.max(1)
#entro = - output * torch.log(output)
#entro = entro.sum(1)
#output = entro

#output = output.ge(4)
output = output.data[0].cpu().numpy()


#cc = cv2.connectedComponents(output)
#print(cc)


f, (ax1, ax2) = plt.subplots(1, 2)
ax1.imshow(I)
ax2.imshow(output, cmap='hot')

plt.show()
