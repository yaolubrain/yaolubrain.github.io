import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable


import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

from PIL import Image

import datasets
from utils import flow_utils, tools


from losses import *

from siamese import Siamese
from devon import Devon
from devon_bn import DevonBN
from devon_mixed import DevonMixed
from devon_mixed_bn import DevonMixedBN
from devon_mixed_multi import DevonMixedMulti
from devon_mixed_0 import DevonMixed0
from devon_mixed_1 import DevonMixed1
from devon_mixed_2 import DevonMixed2

from devon_1 import Devon1
from devon_2 import Devon2
from warpnet import WarpNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()


model = None
if args.model == 'devon':
    model = Devon()
elif args.model == 'devon_nearest':
    model = DevonNearest()
elif args.model == 'devon_0':
    model = Devon0()
elif args.model == 'devon_1':
    model = Devon1()
elif args.model == 'devon_2':
    model = Devon2()
elif args.model == 'devon_mixed':
    model = DevonMixed()
elif args.model == 'devon_mixed_2':
    model = DevonMixed2()
elif args.model == 'devon_mixed_1':
    model = DevonMixed1()
elif args.model == 'devon_mixed_0':
    model = DevonMixed0()
elif args.model == 'devon_mixed_bn':
    model = DevonMixedBN()
elif args.model == 'devon_bn':
    model = DevonBN()
elif args.model == 'devon_same_scale':
    model = DevonSameScale()
elif args.model == 'warpnet':
    model = WarpNet()
elif args.model == 'devon_readout':
    model = DevonReadout()
elif args.model == 'devon_multi_readout':
    model = DevonMultiReadout()
elif args.model == 'devon_mixed_multi':
    model = DevonMixedMulti()
    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.0001_ft_kitti.pt'))


model.cuda()
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001_ft.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_0_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_1e-05_ft.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_bn_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_small_lr_0.001.pt'))

para_num = 0
for p in model.parameters():
    para_num += p.nelement()
print(para_num)    

for param in model.parameters():
      param.requires_grad = False

upsample2 = nn.Upsample(scale_factor=2, mode='nearest')
r_folder = '/home/yao/Code/data/kitti2015/testing/'
w_folder = '/home/yao/Code/data/kitti2015/pred/testing/'


index = 0
I_fname = r_folder + 'image_2/' + '{:06}_10.png'.format(index)
J_fname = r_folder + 'image_2/' + '{:06}_11.png'.format(index)

while isfile(I_fname) and isfile(J_fname):
    print(I_fname, J_fname)
    img1 = Image.open(I_fname)
    img2 = Image.open(J_fname)

    size_w_real = img1.size[0]
    size_h_real = img1.size[1]
    size_w_fake = 1056
    size_h_fake = 384

    upsample = nn.Upsample((size_h_real,size_w_real), mode='bilinear')

    img1 = img1.resize((size_w_fake, size_h_fake), Image.ANTIALIAS)
    img2 = img2.resize((size_w_fake, size_h_fake), Image.ANTIALIAS)
    img1 = np.array(img1).transpose(2,0,1)
    img2 = np.array(img2).transpose(2,0,1)

    img1 = torch.from_numpy(img1.astype(np.float32))
    img2 = torch.from_numpy(img2.astype(np.float32))

    img1.mul_(2/255)
    img2.mul_(2/255)
    img1.add_(-1)
    img2.add_(-1)

    img1 = img1.cuda()
    img2 = img2.cuda()

    input1 = Variable(img1.view(1,3,size_h_fake,size_w_fake))
    input2 = Variable(img2.view(1,3,size_h_fake,size_w_fake))

    output = model(input1, input2)
    output = upsample(output[0])
    output.data[:,0,:,:] *= size_w_real / size_w_fake
    output.data[:,1,:,:] *= size_h_real / size_h_fake
    output = output.data[0].cpu().numpy()
    output = output.transpose(1,2,0)

    flow_fname = w_folder + '{:06}_10.flo'.format(index)
    flow_utils.writeFlow(flow_fname, output)

    index += 1
    I_fname = r_folder + 'image_2/' + '{:06}_10.png'.format(index)
    J_fname = r_folder + 'image_2/' + '{:06}_11.png'.format(index)

