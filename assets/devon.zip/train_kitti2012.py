import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

import datasets
from utils import flow_utils, tools

from losses import *

from siamese import Siamese
from devon import Devon
from devon_bn import DevonBN
from devon_mixed import DevonMixed
from devon_mixed_0 import DevonMixed0
from devon_mixed_1 import DevonMixed1
from devon_mixed_2 import DevonMixed2
from devon_mixed_bn import DevonMixedBN
from devon_mixed_multi import DevonMixedMulti
from warpnet import WarpNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)

args = parser.parse_args()


model = None
if args.model == 'devon':
    model = Devon()
elif args.model == 'devon_nearest':
    model = DevonNearest()
elif args.model == 'devon_0':
    model = Devon0()
elif args.model == 'devon_1':
    model = Devon1()
elif args.model == 'devon_2':
    model = Devon2()
elif args.model == 'devon_mixed':
    model = DevonMixed()
elif args.model == 'devon_mixed_2':
    model = DevonMixed2()
elif args.model == 'devon_mixed_1':
    model = DevonMixed1()
elif args.model == 'devon_mixed_0':
    model = DevonMixed0()
elif args.model == 'devon_mixed_multi':
    model = DevonMixedMulti()
elif args.model == 'devon_mixed_bn':
    model = DevonMixedBN()
elif args.model == 'devon_bn':
    model = DevonBN()
elif args.model == 'devon_same_scale':
    model = DevonSameScale()
elif args.model == 'warpnet':
    model = WarpNet()
elif args.model == 'devon_readout':
    model = DevonReadout()
elif args.model == 'devon_multi_readout':
    model = DevonMultiReadout()

model.cuda()

for p in model.parameters():
    if p.dim() > 1:
        torch.nn.init.kaiming_uniform(p)

args.crop_size = (352, 992)
args.inference_size = (352, 1024)
data_path = '../data/kitti2012/training'

train_dataset = datasets.KITTI2012(args, is_cropped=True, root=data_path)
train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)

print(len(train_dataset))
print(sum(p.numel() for p in model.parameters()))

loss_F = MultiScale(args, 2**args.scale, 4)
#loss_F = Multi(args, args.scale, 3)
#loss_F = nn.L1Loss()
#loss_F = SingleScale(4)

upsample2 = nn.Upsample(scale_factor=2, mode='nearest')
upsample = nn.Upsample(scale_factor=2**args.scale, mode='bilinear')

optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr, weight_decay=0.00001)
scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[400000,600000,800000,1000000], gamma=0.5)

def train_epoch():
    model.train()
    total_error = 0
    progress = tqdm(tools.IteratorTimer(train_loader), ncols=100, total=len(train_loader))
    for i,v in enumerate(progress):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        input1 = Variable(input1)
        input2 = Variable(input2)
        target = Variable(target)
        output = model(input1, input2)

        optimizer.zero_grad()
        losses = loss_F(output, target)
        losses[0].backward()
        optimizer.step()

        total_error += losses[0].data[0]

    return total_error 

def valid():    
    model.eval()
    total_error = 0
    for i,v in enumerate(valid_loader):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        input1 = Variable(input1)
        input2 = Variable(input2)
        target = Variable(target)

        output = model(input1, input2)

        output = 4*upsample(output[0])

        epe = EPE(output, target).data[0]
        total_error += epe
    return total_error / (len(valid_dataset) / args.batch_size)


T = 1000
prev_valid_loss = 0

fname = 'log/train_' + args.model + '_lr_' + str(args.lr)
open(fname, 'w').close()

for t in range(T):

    train_loss = train_epoch()        
    valid_loss = valid() 
    
    scheduler.step()

    printed_line = '{0:d} {1:3f} {2:3f}'.format(t, train_loss, valid_loss)
    print(printed_line)

    torch.save(model.state_dict(), 'models/' + args.model + '_lr_' + str(args.lr) + '.pt')

    with open(fname, 'a') as f:
        f.write(printed_line + '\n')



