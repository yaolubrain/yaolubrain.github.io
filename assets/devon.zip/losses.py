'''
Portions of this code copyright 2017, Clement Pinard
'''

# freda (todo) : adversarial loss 

import torch
import torch.nn as nn
import math


from layers.resample2d_package.modules.resample2d import Resample2d
from layers.cost_volume_package.modules.cost_volume import *

class PWCTrainLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.dnsample4 = nn.AvgPool2d(4,4)
        self.dnsample8 = nn.AvgPool2d(8,8)
        self.dnsample16 = nn.AvgPool2d(16,16)
        self.dnsample32 = nn.AvgPool2d(32,32)
        self.dnsample64 = nn.AvgPool2d(64,64)

    def forward(self, F, G):

        loss0 = torch.pow(F[0] - self.dnsample4(G), 2).mean()
        loss1 = torch.pow(F[1] - self.dnsample8(G), 2).mean()
        loss2 = torch.pow(F[2] - self.dnsample16(G), 2).mean()
        loss3 = torch.pow(F[3] - self.dnsample32(G), 2).mean()
        loss4 = torch.pow(F[4] - self.dnsample64(G), 2).mean()

        loss = 0.32*loss0 + 0.08*loss1 + 0.02*loss2 + 0.01*loss3 + 0.005*loss4

        return loss

        


class ConjugateLoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)

    def forward(self, seg, flo):
        
        cv_seg = self.cv(seg, seg)
        cv_flo = self.cv(flo, flo)

        sim_seg = torch.exp(-cv_seg)
        sim_flo = torch.exp(-cv_flo * 10)

        output = sim_flo * (1-sim_seg) + 0.5*sim_seg * (1-sim_flo)

        return output.mean()


class WarpLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.warp = Resample2d()

    def forward(self, input1, input2, flow):
        warped_input2 = self.warp(input2, flow)
        return torch.norm(input1 - warped_input2, p=1, dim=1).mean()

class LocalSmoothLoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)

    def forward(self, input1):
        cv = self.cv(input1, input1)
        return cv.mean()

class SegSmoothLoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)

    def forward(self, flo, seg):
        cv_flo = self.cv(flo, flo)
        cv_seg = self.cv(seg, seg)
        output = torch.exp(-cv_flo) * cv_seg + torch.exp(-cv_seg) * cv_flo

        return output.mean()

class DTLoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)

    def forward(self, flo, seg):
        cv_flo = self.cv(flo, flo)
        cv_seg = self.cv(seg, seg)
        output = (1+cv_flo) / (1+cv_seg) + (1+cv_seg) / (1+cv_flo)

        return output.mean()

class SNELoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)
        self.softmax = nn.Softmax2d()

    def forward(self, flo, seg):
        cv_flo = self.cv(flo, flo)
        cv_seg = self.cv(seg, seg)

        sim_flo = self.softmax(-cv_flo)
        sim_seg = self.softmax(-cv_seg) + 1e-10

        output = sim_flo * torch.log(sim_flo / sim_seg)

        return output.mean()

class TSNELoss(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.cv = CostVolumeL1(k, k, 1, 1)
        self.softmax = nn.Softmax2d()

    def forward(self, flo, seg):
        cv_flo = self.cv(flo, flo)
        cv_seg = self.cv(seg, seg)

        sim_flo = self.softmax(-cv_flo)
        sim_seg = 1 / (1 + cv_seg)
        sim_seg.div_(sim_seg.sum(1, keepdim=True))

        output = sim_flo * torch.log(sim_flo / sim_seg)

        return output.mean()



    

def EPE(input_flow, target_flow):
    return torch.norm(target_flow-input_flow,p=2,dim=1).mean()

def EPEMasked(input_flow, target_flow, mask):
    n = mask.sum()
    h = mask.size(0)
    w = mask.size(1)
    mask = mask.view(1, 1, h, w).expand_as(input_flow)
    return 1/n * torch.norm(target_flow*mask-input_flow.view_as(target_flow)*mask,p=2,dim=1).sum() 

class L1(nn.Module):
    def __init__(self):
        super(L1, self).__init__()
    def forward(self, output, target):
        lossvalue = torch.abs(output - target).mean()
        return lossvalue

class L2(nn.Module):
    def __init__(self):
        super(L2, self).__init__()
    def forward(self, output, target):
        lossvalue = torch.norm(output-target,p=2,dim=1).mean()
        return lossvalue

class L1Loss(nn.Module):
    def __init__(self, args):
        super(L1Loss, self).__init__()
        self.args = args
        self.loss = L1()
        self.loss_labels = ['L1', 'EPE']

    def forward(self, output, target):
        lossvalue = self.loss(output, target)
        epevalue = EPE(output, target)
        return [lossvalue, epevalue]

class L2Loss(nn.Module):
    def __init__(self, args):
        super(L2Loss, self).__init__()
        self.args = args
        self.loss = L2()
        self.loss_labels = ['L2', 'EPE']

    def forward(self, output, target):
        lossvalue = self.loss(output, target)
        epevalue = EPE(output, target)
        return [lossvalue, epevalue]

class SingleScale(nn.Module):
    def __init__(self, scale = 4, norm= 'L1'):
        super().__init__()

        self.loss = L1()

        self.downsampler = nn.AvgPool2d(2**scale, 2**scale)

    def forward(self, output, target):
        lossvalue = 0
        epevalue = 0

        target_ = self.downsampler(target)
        epevalue = EPE(output, target_)
        lossvalue = self.loss(output, target_)
        return  [lossvalue, epevalue]

class MultiScale(nn.Module):
    def __init__(self, args, startScale = 4, numScales = 5, l_weight= 0.32, norm= 'L1'):
        super(MultiScale,self).__init__()

        self.startScale = startScale
        self.numScales = numScales
        self.loss_weights = [1, 1, 1, 1]
        #self.loss_weights = [0.4, 0.3, 0.2, 0.1, 0.05]
        self.args = args
        self.l_type = norm
        assert(len(self.loss_weights) == self.numScales)

        if self.l_type == 'L1':
            self.loss = L1()
        else:
            self.loss = L2()

        self.multiScales = [nn.AvgPool2d(self.startScale * (2**scale), self.startScale * (2**scale)) for scale in range(self.numScales)]
        self.loss_labels = ['MultiScale-'+self.l_type, 'EPE'],
        self.multi = 20

    def forward(self, output, target):
        lossvalue = 0
        epevalue = 0

        if type(output) is tuple:
            for i, output_ in enumerate(output):
                target_ = 1/(self.startScale * 2**i) * self.multiScales[i](target)
                epevalue += self.loss_weights[i]*EPE(output_, target_)
                lossvalue += self.loss_weights[i]*self.loss(output_, target_)
            return [lossvalue, epevalue]
        else:
            epevalue += EPE(output, target)
            lossvalue += self.loss(output, target)
            return  [lossvalue, epevalue]


class Multi(nn.Module):
    def __init__(self, args, scale = 0, num = 5, weights=[0.4, 0.3, 0.2, 0.1], norm= 'L1'):
        super().__init__()

        self.numScales = num
        self.loss_weights = weights
        self.args = args
        self.l_type = norm
        assert(len(self.loss_weights) == self.numScales)

        if self.l_type == 'L1':
            self.loss = L1()
        else:
            self.loss = L2()

        self.scale = scale
        self.downsample = nn.AvgPool2d(2**scale, 2**scale) 

    def forward(self, output, target):
        lossvalue = 0
        epevalue = 0

        if type(output) is tuple:
            for i, output_ in enumerate(output):
                target_ = target
                epevalue += self.loss_weights[i]*EPE(output_, target_)
                lossvalue += self.loss_weights[i]*self.loss(output_, target_)
            return [lossvalue, epevalue]
        else:
            epevalue += EPE(output, target)
            lossvalue += self.loss(output, target)
            return  [lossvalue, epevalue]


class MultiMask(nn.Module):
    def __init__(self, args, scale = 0, num = 5, weights=[0.4, 0.3, 0.2, 0.1], norm= 'L1'):
        super().__init__()

        self.numScales = num
        self.loss_weights = weights
        self.args = args
        self.l_type = norm
        assert(len(self.loss_weights) == self.numScales)

        if self.l_type == 'L1':
            self.loss = L1()
        else:
            self.loss = L2()

        self.scale = scale

    def forward(self, output, target, mask):
        lossvalue = 0
        epevalue = 0

        if type(output) is tuple:
            for i, output_ in enumerate(output):
                epevalue += self.loss_weights[i]*EPE(output_ * mask, target * mask)
                lossvalue += self.loss_weights[i]*self.loss(output_ * mask, target * mask)
            return [lossvalue, epevalue]
        else:
            epevalue += EPE(output, target)
            lossvalue += self.loss(output, target)
            return  [lossvalue, epevalue]

