import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time
from PIL import Image

import datasets
from utils import flow_utils, tools
import pylab as plt

from losses import *

from layers.correlation_package.modules.correlation import Correlation

x = torch.ones(1,3,5,5).cuda()
y = torch.ones(1,3,5,5).cuda()

X = Variable(x)
Y = Variable(y)

model = Correlation(1, 1, 1, 1, 1, 1).cuda()

z = model(X,Y)
print(z)
