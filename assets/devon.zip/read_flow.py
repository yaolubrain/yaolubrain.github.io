import numpy as np
from utils.flow_utils import read_png_flow

fname = '/home/yao/Code/data/kitti2012/training/flow_noc/000000_10.png'

flow, occ = read_png_flow(fname)

print(np.absolute(flow[0,:,:]).max())
print(np.absolute(flow[1,:,:]).max())
print(occ.sum())

