import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
from submodules import *

class DevonMixed0(nn.Module):

    def __init__(self):
        super().__init__()
        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.g1 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,8,12,16),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.g2 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,6,9,12),
                      ResBlock(128,1,6,9,12),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.g3 = nn.Sequential(
                      nn.Conv2d(123, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,2,3,4),
                      ResBlock(128,1,4,6,8),
                      ResBlock(128,1,4,6,8),
                      nn.Conv2d(128, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')

        self.cv1 = CostVolumeL1(5,5,1,1)
        self.cv2 = CostVolumeL1(7,7,3,3)
        self.cv3 = CostVolumeL1(7,7,9,9)
        self.dcv1 = DeformCostVolumeL1(5,5,1,1,False)
        self.dcv2 = DeformCostVolumeL1(7,7,3,3,False)
        self.dcv3 = DeformCostVolumeL1(7,7,9,9,False)
        self.softmax2d = nn.Softmax2d()

    def forward(self, I, J, F):

        f1_I = self.f1(I)
        f1_J = self.f1(J)

        r1_1 = self.dcv1(f1_I, f1_J, F/4)
        r1_2 = self.dcv2(f1_I, f1_J, F/4)
        r1_3 = self.dcv3(f1_I, f1_J, F/4)
        r1 = torch.cat((r1_1, r1_2, r1_3), dim=1)
        r1 = self.softmax2d(-r1)
        g1 = self.g1(r1) + F

        r2_1 = self.dcv1(f1_I, f1_J, g1/4)
        r2_2 = self.dcv2(f1_I, f1_J, g1/4)
        r2_3 = self.dcv3(f1_I, f1_J, g1/4)
        r2 = torch.cat((r2_1, r2_2, r2_3), dim=1)
        r2 = self.softmax2d(-r2)
        g2 = self.g2(r2) + g1

        r3_1 = self.dcv1(f1_I, f1_J, g2/4)
        r3_2 = self.dcv2(f1_I, f1_J, g2/4)
        r3_3 = self.dcv3(f1_I, f1_J, g2/4)
        r3 = torch.cat((r3_1, r3_2, r3_3), dim=1)
        r3 = self.softmax2d(-r3)
        g3 = self.g3(r3) + g2

        return g3, g2, g1
