import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

import torchvision.utils as vutils
from tensorboardX import SummaryWriter

import pylab as plt

import datasets
from utils import flow_utils, tools

from losses import *

from segnet import SegNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='segnet')
parser.add_argument('--scale', '-s', type=int,  default=0)

args = parser.parse_args()


model = SegNet()
#model.load_state_dict(torch.load('models/segnet_lr_0.001_5x5.pt'))
model.load_state_dict(torch.load('models/segnet_smo_loss_5x5.pt'))
model.cuda()

#for p in model.parameters():
#    if p.dim() > 1:
#        torch.nn.init.kaiming_uniform(p)
args.crop_size = (384, 896)
data_path = '/home/yao/Code/data/MPI-Sintel-complete/training/'

train_dataset = datasets.MpiSintel(args, is_cropped=True, is_resized=False, root=data_path, dstype='clean')
train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, num_workers=4, pin_memory=True)
train_dataset = datasets.MpiSintel(args, is_cropped=True, is_resized=False, root=data_path, dstype='clean')
valid_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, num_workers=4, pin_memory=True)

print(len(train_dataset))

warp_loss = WarpLoss()
smo_loss = SegSmoothLoss(5)
mse_loss = nn.MSELoss()
bce_loss = nn.BCELoss()
dt_loss = DTLoss(5)
sne_loss = SNELoss(3)
tsne_loss = TSNELoss(3)

con_loss = ConjugateLoss(5)

cv = CostVolumeL1(3,3,1,1).cuda()

optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.9)

writer = SummaryWriter()


def train_epoch():
    model.train()
    total_error = 0
    progress = tqdm(tools.IteratorTimer(train_loader), ncols=100, total=len(train_loader))
    for i,v in enumerate(progress):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        input1 = Variable(input1, requires_grad=False)
        target = Variable(target)

        output1 = model(input1)

        optimizer.zero_grad()
        losses = smo_loss(output1, target)
        losses.backward()
        optimizer.step()

        total_error += losses.data[0]

    return total_error 

def valid():    
    model.eval()
    total_error = 0
    for i,v in enumerate(valid_loader):
        input1 = v[0][0].cuda()
        input1 = Variable(input1, requires_grad=False)
        output = model(input1)
        output = cv(output, output)

#        _, seg = output.data.max(1, keepdim=True)
        seg = output.data.sum(1, keepdim=True)

        return  input1.data, seg



T = 1000
prev_valid_loss = 0

fname = 'log/train_' + args.model + '_lr_' + str(args.lr)
open(fname, 'w').close()

for t in range(T):

    train_loss = train_epoch()        
    scheduler.step()
    img, seg = valid()
    img = vutils.make_grid(img, nrow=4, normalize=False, scale_each=False)
    seg = seg.repeat(1,3,1,1)

#    seg = 255 / 9 * seg
    seg = vutils.make_grid(seg, nrow=4, normalize=False, scale_each=False)

    writer.add_scalar('Train_loss', train_loss, t)
    writer.add_image('Images', img, t)
    writer.add_image('Segments', seg, t)

    printed_line = '{0:d} {1:3f}'.format(t, train_loss)
    print(printed_line)

    torch.save(model.state_dict(), 'models/' + args.model + '_lr_' + str(args.lr) + '.pt')

    with open(fname, 'a') as f:
        f.write(printed_line + '\n')
