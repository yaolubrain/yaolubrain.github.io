import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
from submodules import *

class Devon1(nn.Module):

    def __init__(self):
        super().__init__()

        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))

        self.g1 = nn.Sequential(
                      nn.Conv2d(81, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 128, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(128, 64, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(64, 32, 3, 1, 1),
                      nn.LeakyReLU(0.1, True),
                      nn.Conv2d(32, 2, 3, 1, 1))

        self.cv = CostVolumeL1(9,9,1,1)
        self.softmax2d = nn.Softmax2d()
        self.upsample = nn.Upsample(scale_factor=32, mode='nearest')

    def forward(self, I, J):

        f1_I = self.f1(I)
        f1_J = self.f1(J)

        r1 = self.cv(f1_I, f1_J)
        r1 = self.softmax2d(-r1)
        g1 = self.g1(r1)

        return g1
