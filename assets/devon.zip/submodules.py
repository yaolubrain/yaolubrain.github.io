import torch
import torch.nn as nn
import numpy as np

class UNet(nn.Module):
    def __init__(self, num_input):
        super().__init__()

        self.C1 = nn.Conv2d(num_input, 64, 3, 1, 1)
        self.C2 = nn.Conv2d(64, 96, 3, 2, 1)
        self.C3 = nn.Conv2d(96, 128, 3, 2, 1)
        self.C4 = nn.Conv2d(128, 196, 3, 2, 1)
        self.C5 = nn.Conv2d(196, 256, 3, 2, 1)
        self.C6 = nn.Conv2d(256, 256, 3, 1, 1)
        self.D1 = nn.ConvTranspose2d(256, 196, 4, 2, 1)
        self.D2 = nn.ConvTranspose2d(196, 128, 4, 2, 1)
        self.D3 = nn.ConvTranspose2d(128, 96, 4, 2, 1)
        self.D4 = nn.ConvTranspose2d(96, 64, 4, 2, 1)

        self.L1 = nn.Conv2d(64, 64, 3, 1, 1)
        self.L2 = nn.Conv2d(64,  2, 3, 1, 1)

        self.f  = nn.LeakyReLU(0.1, True)

    def forward(self, x):
        x1 = self.f(self.C1(x))
        x2 = self.f(self.C2(x1))
        x3 = self.f(self.C3(x2))
        x4 = self.f(self.C4(x3))
        x5 = self.f(self.C5(x4))
        x6 = self.f(self.C6(x5))
        x7 = self.f(self.D1(x6)) + x4
        x8 = self.f(self.D2(x7)) + x3
        x9 = self.f(self.D3(x8)) + x2
        x10 = self.f(self.D4(x9)) + x1
        x11 = self.f(self.L1(x10))
        x12 = self.L2(x11)

        return x12




def decoder():
    return nn.Sequential(
        nn.Conv2d(81, 128, 3, 1, 1),
        nn.LeakyReLU(0.1, inplace=True),
        nn.Conv2d(128, 128, 3, 1, 1),
        nn.LeakyReLU(0.1, inplace=True),
        nn.Conv2d(128, 96, 3, 1, 1),
        nn.LeakyReLU(0.1, inplace=True),
        nn.Conv2d(96, 64, 3, 1, 1),
        nn.LeakyReLU(0.1, inplace=True),
        nn.Conv2d(64, 32, 3, 1, 1),
        nn.LeakyReLU(0.1, inplace=True),
        nn.Conv2d(32, 2, 3, 1, 1))

class ResBlock(nn.Module):
    def __init__(self, num_input, d1=1, d2=2, d3=3, d4=4):
        super().__init__()

        num_output = int(num_input / 4)

        self.conv1_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv1_2 = nn.Conv2d(num_output,num_output, 3, 1, d1, d1)
        self.conv2_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv2_2 = nn.Conv2d(num_output, num_output, 3, 1, d2, d2)
        self.conv3_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv3_2 = nn.Conv2d(num_output, num_output, 3, 1, d3, d3)
        self.conv4_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv4_2 = nn.Conv2d(num_output, num_output, 3, 1, d4, d4)

        self.f = nn.LeakyReLU(0.1, True)


    def forward(self, x):
        
        conv1 = self.conv1_2(self.f(self.conv1_1(x)))
        conv2 = self.conv2_2(self.f(self.conv2_1(x)))
        conv3 = self.conv3_2(self.f(self.conv3_1(x)))
        conv4 = self.conv4_2(self.f(self.conv4_1(x)))

        conv5 = torch.cat((conv1,conv2,conv3,conv4), dim=1)
        conv5 = self.f(conv5)

        x = x + conv5 

        return x

class ResBlockBN(nn.Module):
    def __init__(self, num_input, d1=1, d2=2, d3=3, d4=4):
        super().__init__()

        num_output = int(num_input / 4)

        self.conv1_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv1_2 = nn.Conv2d(num_output,num_output, 3, 1, d1, d1)
        self.conv2_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv2_2 = nn.Conv2d(num_output, num_output, 3, 1, d2, d2)
        self.conv3_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv3_2 = nn.Conv2d(num_output, num_output, 3, 1, d3, d3)
        self.conv4_1 = nn.Conv2d(num_input, num_output, 1, 1, 0)
        self.conv4_2 = nn.Conv2d(num_output, num_output, 3, 1, d4, d4)

        self.conv5 = nn.Conv2d(num_input, num_input, 1, 1, 0)

        self.f = nn.LeakyReLU(0.1, True)
        self.bn = nn.BatchNorm2d(num_input)


    def forward(self, x):
        
        conv1 = self.conv1_2(self.f(self.conv1_1(x)))
        conv2 = self.conv2_2(self.f(self.conv2_1(x)))
        conv3 = self.conv3_2(self.f(self.conv3_1(x)))
        conv4 = self.conv4_2(self.f(self.conv4_1(x)))

        conv5 = torch.cat((conv1,conv2,conv3,conv4), dim=1)
        conv5 = self.f(self.conv5(self.f(conv5)))

        conv5 = self.bn(conv5)

        x = x + conv5 

        return x


def readout():
    
    l = nn.Conv2d(81, 2, 1, 1, 0, bias=False)
    X,Y = np.mgrid[-4:5:1, -4:5:1]
    #xy = np.vstack((Y.flatten(), X.flatten()))
    xy = np.vstack((X.flatten(), Y.flatten()))
    xy = xy.reshape(2,81,1,1)
    l.weight.data.copy_(torch.Tensor(xy))
    l.weight.requires_grad = False

    return l 


