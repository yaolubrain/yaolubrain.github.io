import torch
import torch.nn as nn
import numpy as np
from layers.cost_volume_package.modules.cost_volume import *

l = nn.Conv2d(81, 2, 1, 1, 0, bias=False)
print(l.weight.size())

X,Y = np.mgrid[-4:5:1, -4:5:1]
xy = np.vstack((X.flatten(), Y.flatten()))
#xy = np.vstack((Y.flatten(), X.flatten()))
print(xy)
xy = xy.reshape(2,81,1,1)
l.weight.data.copy_(torch.Tensor(xy))
l.weight.requires_grad = False


module = DeformCostVolumeL1(9,9,1,1)
softmax = nn.Softmax2d()

a = torch.randn(1,1,5,5)
b = torch.randn(1,1,5,5)
a = b
f = torch.ones(1,2,5,5)
f[:,0,:,:].fill_(0)
f[:,1,:,:].fill_(-1)



c = module(a,b,f)
c = softmax(-c)
print(c.max(1))
c = l(c)

print(a,b)
print(c)
