clear all;
close all
n = 201;

I = zeros(n);

cx = 100;
cy = 100;

% (1,4) (8,3) (20,3)
% (1,4) (6,3) (15,3)
% (1,4) (5,3) (6,3)

d = 1;
k = 4;
for i = -k:k
    for j = -k:k
        x = cx + i*d;
        y = cy + j*d;
        I(x,y) = 1;
    end    
end

d = 7;
k = 3;
for i = -k:k
    for j = -k:k
        x = cx + i*d;
        y = cy + j*d;
        I(x,y) = 1;
    end    
end

d = 12;
k = 3;
for i = -k:k
    for j = -k:k
        x = cx + i*d;
        y = cy + j*d;
        I(x,y) = 1;
    end    
end


I = (1-I) * 255;
surf(I);
view(0,90);
axis equal
axis([1,201,1,201])
colormap('gray');

    
