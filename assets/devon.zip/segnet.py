import torch
import torch.nn as nn
from layers.cost_volume_package.modules.cost_volume import *
#from layers.correlation_package.modules.correlation import Correlation
from submodules import *

class SegNet(nn.Module):

    def __init__(self):
        super().__init__()

        self.f1 = nn.Sequential(
                      nn.Conv2d(3, 32, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f2 = nn.Sequential(
                      nn.Conv2d(32, 64, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f3 = nn.Sequential(
                      nn.Conv2d(64, 128, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f4 = nn.Sequential(
                      nn.Conv2d(128, 256, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f5 = nn.Sequential(
                      nn.Conv2d(256, 512, 3, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f6 = nn.Sequential(
                      nn.Conv2d(512, 512, 3, 1, 1),
                      nn.LeakyReLU(0.1, True))

        self.f7 = nn.Sequential(
                      nn.ConvTranspose2d(512, 256, 4, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f8 = nn.Sequential(
                      nn.ConvTranspose2d(256, 128, 4, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f9 = nn.Sequential(
                      nn.ConvTranspose2d(128, 64, 4, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f10 = nn.Sequential(
                      nn.ConvTranspose2d(64, 32, 4, 2, 1),
                      nn.LeakyReLU(0.1, True))
        self.f11 = nn.Sequential(
                      nn.ConvTranspose2d(32, 10, 4, 2, 1))

#        self.output = nn.Identity()
        self.cv = CostVolumeL1(3,3,1,1)
#        self.corr = Correlation(1, 1, 1, 1, 1, 1)
        self.softmax = nn.Softmax2d()
        self.sigmoid = nn.Sigmoid()

    def forward(self, I):

        f1_I = self.f1(I)
        f2_I = self.f2(f1_I)
        f3_I = self.f3(f2_I)
        f4_I = self.f4(f3_I)
        f5_I = self.f5(f4_I)
        f6_I = self.f6(f5_I)
        f7_I = self.f7(f6_I)    + f4_I
        f8_I = self.f8(f7_I)    + f3_I
        f9_I = self.f9(f8_I)    + f2_I
        f10_I = self.f10(f9_I)  + f1_I
        f11_I = self.f11(f10_I)
        
        f_I = f11_I

#        f_I = torch.exp(-self.cv(f11_I, f11_I))
#        f_I = self.softmax(-self.output(f11_I, f11_I))
#        f_I = self.sigmoid(f_I)
#        f_I = self.softmax(f11_I)

#        f_I = self.corr(f11_I, f11_I)
#        f_I = self.sigmoid(f_I)
#        f_I = self.cv(f11_I, f11_I)
#        f_I = torch.exp(-f_I)

        return f_I
