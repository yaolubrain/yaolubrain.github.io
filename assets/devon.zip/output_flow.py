import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time
from PIL import Image

import datasets
from utils import flow_utils, tools

from losses import *

from siamese import Siamese
from devon import Devon
from devon_1 import Devon1
from devon_bn import DevonBN
from devon_same_scale import DevonSameScale
from devon_mixed import DevonMixed
from warpnet import WarpNet
from devon_small import DevonSmall

from devon_mixed_multi import DevonMixedMulti

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)
parser.add_argument('--num', '-n', type=int,  default=0)

args = parser.parse_args()


model = None
if args.model == 'devon':
    model = Devon()
    model.load_state_dict(torch.load('models/devon_lr_0.001_decay_0.00001.pt'))
elif args.model == 'devon_1':
    model = Devon1()
elif args.model == 'devon_small':
    model = DevonSmall()
elif args.model == 'devon_mixed':
    model = DevonMixed()
    #model.load_state_dict(torch.load('models/devon_mixed_lr_1e-05_things_ft.pt'))
elif args.model == 'devon_nearest':
    model = DevonNearest()
elif args.model == 'devon_bn':
    model = DevonBN()
elif args.model == 'devon_same_scale':
    model = DevonSameScale()
elif args.model == 'warpnet':
    model = WarpNet()
elif args.model == 'devon_readout':
    model = DevonReadout()
elif args.model == 'devon_multi_readout':
    model = DevonMultiReadout()
elif args.model == 'devon_mixed_multi':
    model = DevonMixedMulti()
    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001.pt'))
    #model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.001_decay_0.00001.pt'))
#    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_1e-05_things_ft.pt'))


model.cuda()
#model.load_state_dict(torch.load('models/devon_small_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_1e-05_things_ft.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001_ft.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_1e-05_ft.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001.pt'))
#model.load_state_dict(torch.load('models/devon_bn_lr_0.001decay_0.00001.pt'))

args.crop_size = (384, 448)
args.inference_size = (384, 512)


upsample = nn.Upsample((436,1024), mode='bilinear')


img1 = Image.open('/home/yao/Code/data/eval-data/Army/frame10.png')
img2 = Image.open('/home/yao/Code/data/eval-data/Army/frame11.png')
img1 = Image.open('/home/yao/Code/data/FlyingChairs_release/data/00043_img1.ppm')
img2 = Image.open('/home/yao/Code/data/FlyingChairs_release/data/00043_img2.ppm')
#img1 = Image.open('/home/yao/Code/devon/checker_I.png')
#img2 = Image.open('/home/yao/Code/devon/checker_J.png')

#img1 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/final/alley_1/frame_0013.png')
#img2 = Image.open('/home/yao/Code/data/MPI-Sintel-complete/training/final/alley_1/frame_0014.png')
#img1 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_10.png')
#img2 = Image.open('/home/yao/Code/data/kitti2015/training/image_2/000000_11.png')
size_w_real = img1.size[0]
size_h_real = img1.size[1]
size_w_fake = 1056
size_h_fake = 384
size_w_fake = 512
size_h_fake = 384
#size_w_fake = 1024
#size_h_fake = 448



#img1 = img1.resize((1024, 448), Image.ANTIALIAS)
#img2 = img2.resize((1024, 448), Image.ANTIALIAS)
#img1 = img1.resize((1056, 384), Image.ANTIALIAS)
#img2 = img2.resize((1056, 384), Image.ANTIALIAS)
#img1 = img1.resize((512//4, 384//4), Image.ANTIALIAS)
#img2 = img2.resize((512//4, 384//4), Image.ANTIALIAS)



img1 = np.array(img1).transpose(2,0,1)
img2 = np.array(img2).transpose(2,0,1)
#img1 = np.array(img1).transpose(1,0)
#img2 = np.array(img2).transpose(1,0)

img1 = torch.from_numpy(img1.astype(np.float32)).clone()
img2 = torch.from_numpy(img2.astype(np.float32)).clone()

h = img1.size()[1]
w = img1.size()[2]

img1 = img1.view(1,3,h,w).clone()
img2 = img2.view(1,3,h,w).clone()

img1.mul_(2/255)
img2.mul_(2/255)
img1.add_(-1)
img2.add_(-1)

downsample = nn.AvgPool2d(2,2)



input1 = img1.cuda()
input2 = img2.cuda()

print(input1.size())
print(input2.size())

input1 = Variable(input1)
input2 = Variable(input2)
input1 = downsample(input1)
input2 = downsample(input2)

output = model(input1, input2)
#output_up = upsample(output[0])
#output_up.data[:,1,:,:] *= 436 / 448

upsample = nn.Upsample((size_h_real,size_w_real), mode='bilinear')
output = upsample(output[1])
output.data[:,0,:,:] *= size_w_real / size_w_fake
output.data[:,1,:,:] *= size_h_real / size_h_fake


#target = target.data[0].cpu().numpy()
#target = target.transpose(1,2,0)

#output_up = output[0]

flow = output.data[0].cpu().numpy()
flow = flow.transpose(1,2,0)
flow_utils.writeFlow('output1.flo', flow)

