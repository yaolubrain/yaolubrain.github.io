import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable
from tqdm import tqdm

import argparse, os, sys, subprocess, math
import numpy as np
from glob import glob
from os.path import *
import time

import datasets
from utils import flow_utils, tools

from losses import *

from PWCNet import *

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                    help='learning rate (default: 1e-3)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')

args = parser.parse_args()


model = PWCDCNet()


for p in model.parameters():
    if p.dim() > 1:
        torch.nn.init.kaiming_uniform(p)

args.crop_size = (384, 448)
args.inference_size = (384, 512)

data_path = 'data/FlyingChairs_release/'
train_dataset = datasets.FlyingChairs(args, is_train=True, is_cropped=True, scale=args.scale, root=data_path)
train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)


print(len(train_dataset))



optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

model.cuda()

def train_epoch():
    model.train()
    total_error = 0
    progress = tqdm(tools.IteratorTimer(train_loader), ncols=100, total=len(train_loader))
    for i,v in enumerate(progress):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        output = model(input1, input2)

        optimizer.zero_grad()
        losses = loss_F(output, target)
        losses[0].backward()
        optimizer.step()

        total_error += losses[0].data[0]

    return total_error 

def valid():    
    model.eval()
    total_error = 0
    for i,v in enumerate(valid_loader):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()

        output = model(input1, input2)

        epe = EPE(output, target).data[0]
        total_error += epe
    return total_error / (len(valid_dataset) / args.batch_size)


T = 1000
prev_valid_loss = 0

fname = 'log/train_' + args.model + '_lr_' + str(args.lr)
open(fname, 'w').close()

for t in range(T):

    train_loss = train_epoch()        
    valid_loss = valid() 
    print(valid_loss)
    
    scheduler.step()

    printed_line = '{0:d} {1:3f} {2:3f}'.format(t, train_loss, valid_loss)
    print(printed_line)

    torch.save(model.state_dict(), 'models/' + args.model + '_lr_' + str(args.lr) + '.pt')

    with open(fname, 'a') as f:
        f.write(printed_line + '\n')



