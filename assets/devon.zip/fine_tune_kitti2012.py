import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.autograd import Variable

import argparse, os, sys, subprocess, math
import numpy as np
from tqdm import tqdm
from glob import glob
from os.path import *
import time

import datasets
from utils import flow_utils, tools

from losses import *

from siamese import Siamese
from devon import Devon
from devon_bn import DevonBN
from devon_1 import Devon1
from devon_2 import Devon2
from devon_same_scale import DevonSameScale
from devon_mixed import DevonMixed
from devon_mixed_bn import DevonMixedBN
from devon_readout import DevonReadout
#from devon_multi_readout import DevonMultiReadout
from devon_mixed_multi import DevonMixedMulti
from warpnet import WarpNet

parser = argparse.ArgumentParser(description='Optical Flow')
parser.add_argument('--batch_size', type=int, default=8, metavar='N',
                    help='input batch size for training (default: 8)')
parser.add_argument('--epochs', type=int, default=100, metavar='N',
                    help='number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-5, metavar='LR',
                    help='learning rate (default: 1e-5)')
parser.add_argument('--seed', type=int, default=1, metavar='S',
                    help='random seed (default: 1)')
parser.add_argument('--optim', '-o',  default='adam')
parser.add_argument('--model', '-m',  default='devon')
parser.add_argument('--scale', '-s', type=int,  default=0)

args = parser.parse_args()


model = None
if args.model == 'devon':
    model = Devon()
elif args.model == 'devon_nearest':
    model = DevonNearest()
elif args.model == 'devon_1':
    model = Devon1()
elif args.model == 'devon_2':
    model = Devon2()
elif args.model == 'devon_mixed':
    model = DevonMixed()
    model.load_state_dict(torch.load('models/devon_mixed_lr_0.001.pt'))
elif args.model == 'devon_mixed_bn':
    model = DevonMixedBN()
elif args.model == 'devon_bn':
    model = DevonBN()
elif args.model == 'devon_same_scale':
    model = DevonSameScale()
elif args.model == 'warpnet':
    model = WarpNet()
elif args.model == 'devon_readout':
    model = DevonReadout()
elif args.model == 'devon_multi_readout':
    model = DevonMultiReadout()
elif args.model == 'devon_mixed_multi':
    model = DevonMixedMulti()
    model.load_state_dict(torch.load('models/devon_mixed_multi_lr_0.0001_things_ft.pt'))

#model.load_state_dict(torch.load('models/devon_bn_lr_0.001decay_0.00001.pt'))
#model.load_state_dict(torch.load('models/devon_mixed_lr_0.001.pt'))
model.cuda()

args.crop_size = (352, 992)
args.inference_size = (352, 1024)

data_path = '../data/kitti2012/training'
train_dataset = datasets.KITTI2012(args, is_cropped=True, root=data_path)
train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)

print(len(train_dataset))

loss_F = Multi(args, 0, 4, [0.4, 0.3, 0.2, 0.1])

upsample1 = nn.Upsample(scale_factor=4, mode='bilinear')
upsample2 = nn.Upsample(scale_factor=16, mode='bilinear')

optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr, weight_decay=0.00001)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.8)

def train_epoch():
    model.train()
    total_error = 0
    progress = tqdm(tools.IteratorTimer(train_loader), ncols=100, total=len(train_loader))
    for i,v in enumerate(progress):
        input1 = v[0][0].cuda()
        input2 = v[0][1].cuda()
        target = v[1][0].cuda()
        occmap = v[2][0].cuda()

        input1 = Variable(input1)
        input2 = Variable(input2)
        target = Variable(target)
        occmap = Variable(occmap)

        b = occmap.size()[0]
        h = occmap.size()[1]
        w = occmap.size()[2]
        occmap = occmap.view(b, 1, h, w).expand_as(target)

        output = model(input1, input2)

        for out in output:
            out.mul_(occmap)
        target.mul_(occmap)

        optimizer.zero_grad()
        losses = loss_F(output, target)
        losses[0].backward()
        optimizer.step()

        total_error += losses[0].data[0]

    return total_error 

T = 1000
prev_valid_loss = 0

for t in range(T):

    train_loss = train_epoch()        

    scheduler.step()
    
    printed_line = '{0:d} {1:3f}'.format(t, train_loss)
    print(printed_line)

    torch.save(model.state_dict(), 'models/' + args.model + '_lr_' + str(args.lr) + '_ft_kitti2012.pt')



