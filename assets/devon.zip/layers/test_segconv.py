import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.autograd import gradcheck

from segconv.functions.segconv import *
from segconv.modules.segconv import *

x = 1*torch.randn(1,3,5,5)
y = 1*torch.randn(1,9,5,5)

x = x.cuda()
y = y.cuda()

X = Variable(x,requires_grad=True)
Y = Variable(y,requires_grad=True)

model = SegConv2d(3, 3, 3, 1, 0, 1)
model.cuda()

F = SegConv2dFunction()

W = Variable(model.weight.data, requires_grad=True)
B = Variable(model.bias.data, requires_grad=True)

inputs = (X,Y,W,B,3,1,1,1)
test = gradcheck(F.apply, inputs, eps=1e-2, atol=1e-3)
print(test)

Z = model.forward(X, Y)

# test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)

##
#CV = CostVolumeL1Function()
#input = (X,Y,3,3,1,1,1,1)
#test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)
#print(test)
##
#CV = DeformCostVolumeL1Function()
##
#input = (X,Y,F,3,3,1,1,1,1,True)
#test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)
##
#
#M = CostVolumeDotProd(3,3,1,1)
#
#Z = M(X, Y)
#C = Z.abs().mean()
#C.backward()
#
#print(X.grad)
#print(Y.grad)
#print(C)
#
#XX = Variable(x.cuda(), requires_grad=True)
#YY = Variable(y.cuda(), requires_grad=True)
#FF = Variable(f,requires_grad=True)
#MM = CostVolumeDotProd(3,3,1,1)
#
#ZZ = MM(XX, YY)
#CC = ZZ.abs().mean()
#CC.backward()
#
#print(XX.grad)
#print(YY.grad)
#print(CC)

#Z.sum().backward()
#
#print(XX.grad)
#print(YY.grad)

