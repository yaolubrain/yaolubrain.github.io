import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.autograd import gradcheck

from cost_volume_package.functions.cost_volume import *
from cost_volume_package.modules.cost_volume import *


x = 1*torch.randn(1,3,5,5)
y = 1*torch.randn(1,3,5,5)
f = (torch.rand(1,2,3,3) - 0.5) * 2

x = x.cuda()
y = y.cuda()
f = f.cuda()

X = Variable(x,requires_grad=True)
Y = Variable(y,requires_grad=True)
F = Variable(f,requires_grad=True)

CV = CostVolumeL2Function()
input = (X,Y,3,3,1,1,1,1)
test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)
print(test)

##
#CV = CostVolumeL1Function()
#input = (X,Y,3,3,1,1,1,1)
#test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)
#print(test)
##
#CV = DeformCostVolumeL1Function()
##
#input = (X,Y,F,3,3,1,1,1,1,True)
#test = gradcheck(CV.apply, input, eps=1e-2, atol=1e-3)
##
#
#M = CostVolumeDotProd(3,3,1,1)
#
#Z = M(X, Y)
#C = Z.abs().mean()
#C.backward()
#
#print(X.grad)
#print(Y.grad)
#print(C)
#
#XX = Variable(x.cuda(), requires_grad=True)
#YY = Variable(y.cuda(), requires_grad=True)
#FF = Variable(f,requires_grad=True)
#MM = CostVolumeDotProd(3,3,1,1)
#
#ZZ = MM(XX, YY)
#CC = ZZ.abs().mean()
#CC.backward()
#
#print(XX.grad)
#print(YY.grad)
#print(CC)

#Z.sum().backward()
#
#print(XX.grad)
#print(YY.grad)

