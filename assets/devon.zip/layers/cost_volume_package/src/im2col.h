#include <string.h>

#define min(a,b) ((a<b)?(a):(b))
#define max(a,b) ((a>b)?(a):(b))

void im2col(float* data_im, int channels,
      int height, int width, int kernel_h, int kernel_w,
      int pad_h, int pad_w,
      int stride_h, int stride_w,
      int dilation_h, int dilation_w,
      float* data_col) {
  int height_col = (height + 2 * pad_h -
                          (dilation_h * (kernel_h - 1) + 1)) / stride_h + 1;
  int width_col = (width + 2 * pad_w -
                         (dilation_w * (kernel_w - 1) + 1)) / stride_w + 1;
  int channels_col = channels * kernel_h * kernel_w;

  int c_col, h_col, w_col;
  for (c_col = 0; c_col < channels_col; ++c_col) {
    int w_offset = c_col % kernel_w;
    int h_offset = (c_col / kernel_w) % kernel_h;
    int c_im = c_col / kernel_h / kernel_w;
    for (h_col = 0; h_col < height_col; ++h_col) {
      for (w_col = 0; w_col < width_col; ++w_col) {
        int h_im = h_col * stride_h - pad_h + h_offset * dilation_h;
        int w_im = w_col * stride_w - pad_w + w_offset * dilation_w;
        data_col[(c_col * height_col + h_col) * width_col + w_col] =
          (h_im >= 0 && w_im >= 0 && h_im < height && w_im < width) ?
          data_im[(c_im * height + h_im) * width + w_im] : 0;
      }
    }
  }
}

void col2im(float* data_col, int channels,
      int height, int width,
      int output_height, int output_width,
      int kernel_h, int kernel_w,
      int pad_h, int pad_w,
      int stride_h, int stride_w,
      int dilation_h, int dilation_w,
      float* data_im) {
  memset(data_im, 0, sizeof(float) * height * width * channels);
  int height_col = output_height;
  int width_col = output_width;
  int channels_col = channels * kernel_h * kernel_w;

  int c_col, h_col, w_col;
  for (c_col = 0; c_col < channels_col; ++c_col) {
    int w_offset = c_col % kernel_w;
    int h_offset = (c_col / kernel_w) % kernel_h;
    int c_im = c_col / kernel_h / kernel_w;
    for (h_col = 0; h_col < height_col; ++h_col) {
      for (w_col = 0; w_col < width_col; ++w_col) {
        int h_im = h_col * stride_h - pad_h + h_offset * dilation_h;
        int w_im = w_col * stride_w - pad_w + w_offset * dilation_w;
        if (h_im >= 0 && h_im < height && w_im >= 0 && w_im < width)
          data_im[(c_im * height + h_im) * width + w_im] +=
            data_col[(c_col * height_col + h_col) * width_col + w_col];
      }
    }
  }
}

void im2col_flow(float* data_im, 
                 float* data_flow, 
                 int channels,   int height, int width, 
                 int kernel_h,   int kernel_w,
                 int pad_h,      int pad_w,
                 int stride_h,   int stride_w,
                 int dilation_h, int dilation_w,
                 float* data_col) 
{

  int height_col = (height + 2 * pad_h -
              (dilation_h * (kernel_h - 1) + 1)) / stride_h + 1;
  int width_col = (width + 2 * pad_w -
              (dilation_w * (kernel_w - 1) + 1)) / stride_w + 1;

  int num_kernels = channels * height_col * width_col;

  int index, i, j;

  for (index = 0; index < num_kernels; ++index) {

    int h_index = index / width_col;
    int h_col = h_index % height_col;
    int w_col = index % width_col;
    int c_im = h_index / height_col;
    int c_col = c_im * kernel_h * kernel_w;
    int h_offset = h_col * stride_h - pad_h;
    int w_offset = w_col * stride_w - pad_w;

    float flow_h = data_flow[1*height_col*width_col + h_col*width_col + w_col];
    float flow_w = data_flow[0*height_col*width_col + h_col*width_col + w_col];

    float* data_col_ptr = data_col + (c_col * height_col + h_col) * width_col + w_col;
    float* data_im_ptr  = data_im  + c_im * height * width;

    for (i = 0; i < kernel_h; ++i) {
      for (j = 0; j < kernel_w; ++j) {
        float h_im = (float) h_offset + i*dilation_h + flow_h;
        float w_im = (float) w_offset + j*dilation_w + flow_w;

        if (h_im < 0 || w_im < 0 || h_im >= height || w_im >= width) {
          *data_col_ptr = 0;
        } else {
          int h_im_T = (int) h_im;
          int w_im_L = (int) w_im;
          int h_im_B = min(h_im_T+1, height-1);
          int w_im_R = min(w_im_L+1, width-1);

          float alpha = w_im - w_im_L;
          float beta  = h_im - h_im_T;

          float coeffTL = (1-alpha)*(1-beta);
          float coeffTR = alpha*(1-beta);
          float coeffBL = (1-alpha)*beta;
          float coeffBR = alpha*beta;

          *data_col_ptr = coeffTL * data_im_ptr[h_im_T*width + w_im_L]
                        + coeffTR * data_im_ptr[h_im_T*width + w_im_R]
                        + coeffBL * data_im_ptr[h_im_B*width + w_im_L]
                        + coeffBR * data_im_ptr[h_im_B*width + w_im_R];
        }

        data_col_ptr += height_col * width_col;
      }
    }
  }
}

void col2im_flow(float* data_im, 
                 float* data_flow, 
                 float* data_fgradInput, 
                 int channels,   int height, int width, 
                 int kernel_h,   int kernel_w,
                 int pad_h,      int pad_w,
                 int stride_h,   int stride_w,
                 int dilation_h, int dilation_w,
                 int updateGradFlow,
                 float* data_gradInput, float* data_gradFlow) 
{
  int height_col = (height + 2 * pad_h -
              (dilation_h * (kernel_h - 1) + 1)) / stride_h + 1;
  int width_col = (width + 2 * pad_w -
              (dilation_w * (kernel_w - 1) + 1)) / stride_w + 1;

  int num_kernels = channels * height_col * width_col;

  int index, i, j;

  for (index = 0; index < num_kernels; ++index) {
    int h_index = index / width_col;
    int h_col = h_index % height_col;
    int w_col = index % width_col;
    int c_im = h_index / height_col;
    int c_col = c_im * kernel_h * kernel_w;
    int h_offset = h_col * stride_h - pad_h;
    int w_offset = w_col * stride_w - pad_w;

    float flow_h = data_flow[1*height_col*width_col + h_col*width_col + w_col];
    float flow_w = data_flow[0*height_col*width_col + h_col*width_col + w_col];

    int im_offset = c_im * height * width;
    float* data_fgradInput_ptr = data_fgradInput + (c_col * height_col + h_col) * width_col + w_col;
    float* data_gradInput_ptr  = data_gradInput  + im_offset;
    float* data_im_ptr = data_im + im_offset;

    for (i = 0; i < kernel_h; ++i) {
      for (j = 0; j < kernel_w; ++j) {
        float h_im = (float) h_offset + i*dilation_h + flow_h;
        float w_im = (float) w_offset + j*dilation_w + flow_w;

        if (h_im >= 0 && w_im >= 0 && h_im < height && w_im < width) {
          int h_im_T = (int) h_im;
          int h_im_B = min(h_im_T+1, height-1);
          int w_im_L = (int) w_im;
          int w_im_R = min(w_im_L+1, width-1);

          float alpha = w_im - w_im_L;
          float beta  = h_im - h_im_T;

          float coeffTL = (1-alpha)*(1-beta);
          float coeffTR = alpha*(1-beta);
          float coeffBL = (1-alpha)*beta;
          float coeffBR = alpha*beta;

          data_gradInput_ptr[h_im_T*width + w_im_L] += coeffTL * (*data_fgradInput_ptr);
          data_gradInput_ptr[h_im_T*width + w_im_R] += coeffTR * (*data_fgradInput_ptr);
          data_gradInput_ptr[h_im_B*width + w_im_L] += coeffBL * (*data_fgradInput_ptr);
          data_gradInput_ptr[h_im_B*width + w_im_R] += coeffBR * (*data_fgradInput_ptr);

          if (updateGradFlow) {
            float gamma = (float) w_im_R - w_im;
            float coeff = gamma * (data_im_ptr[(h_im_B)*width + w_im_L] - data_im_ptr[(h_im_T)*width + w_im_L])
                   + (1-gamma) * (data_im_ptr[(h_im_B)*width + w_im_R] - data_im_ptr[(h_im_T)*width + w_im_R]);
            data_gradFlow[1*height_col*width_col + h_col*width_col + w_col] += coeff * (*data_fgradInput_ptr);

            gamma = (float) h_im_B - h_im;
            coeff = gamma * (data_im_ptr[(h_im_T)*width + w_im_R] - data_im_ptr[(h_im_T)*width + w_im_L])  
              + (1-gamma) * (data_im_ptr[(h_im_B)*width + w_im_R] - data_im_ptr[(h_im_B)*width + w_im_L]);
            data_gradFlow[0*height_col*width_col + h_col*width_col + w_col] += coeff * (*data_fgradInput_ptr);
          }
        }

        data_fgradInput_ptr += height_col * width_col;
      }
    }
  }
}


