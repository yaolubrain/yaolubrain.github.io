#include <THC/THC.h>
#include "im2col_cuda.h"

// this symbol will be resolved automatically from PyTorch libs
extern THCState *state;

int cost_volume_dotprod_forward_cuda(THCudaTensor *input1, 
                                     THCudaTensor *input2,
                                     THCudaTensor *output,
                                     int kW, int kH,
                                     int padW, int padH,
                                     int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THCudaTensor_resize4d(state, output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *output_t = THCudaTensor_newSelect(state, output, 0, t);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cmul(state, finput2_t, input1_t_expand, finput2_t);
    THCudaTensor_sum(state, output_t, finput2_t, 0, 0);

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, output_t);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
  }

  return 1;
}

int cost_volume_dotprod_backward_cuda(THCudaTensor *input1,
                                    THCudaTensor *input2,
                                    THCudaTensor *grad_output, 
                                    THCudaTensor *grad_input1, 
                                    THCudaTensor *grad_input2,
                                    int kW, int kH,
                                    int padW, int padH,
                                    int dilationW, int dilationH)
{
  THCudaTensor_resizeAs(state, grad_input1, input1);
  THCudaTensor_resizeAs(state, grad_input2, input2);
  THCudaTensor_fill(state, grad_input1, 0.0);
  THCudaTensor_fill(state, grad_input2, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *grad_output_t = THCudaTensor_newSelect(state, grad_output, 0, t);
    THCudaTensor *grad_input1_t = THCudaTensor_newSelect(state, grad_input1, 0, t);
    THCudaTensor *grad_input2_t = THCudaTensor_newSelect(state, grad_input2, 0, t);

    // grad_input1
    THCudaTensor *fgrad_output_t_expand = THCudaTensor_newWithStorage3d(state,
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);


    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);

    THCudaTensor *fgrad_input1_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cmul(state, fgrad_input1_t, finput2_t, fgrad_output_t_expand);

    THCudaTensor *fgrad_input1_t_sum = THCudaTensor_newWithSize2d(state, nInputPlane, inputHeight*inputWidth);
    THCudaTensor_sum(state, fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THCudaTensor_resize3d(state, fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THCudaTensor_copy(state, grad_input1_t, fgrad_input1_t_sum);

    // grad_input2
    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *fgrad_input2_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cmul(state, fgrad_input2_t, input1_t_expand, fgrad_output_t_expand);

    col2im_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, fgrad_input2_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, grad_input2_t)
    );

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_input1_t);
    THCudaTensor_free(state, grad_input2_t);
    THCudaTensor_free(state, fgrad_output_t_expand);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
    THCudaTensor_free(state, fgrad_input1_t);
    THCudaTensor_free(state, fgrad_input1_t_sum);
    THCudaTensor_free(state, fgrad_input2_t);
  }

  return 1;
}


int cost_volume_l2_forward_cuda(THCudaTensor *input1, 
                                THCudaTensor *input2,
                                THCudaTensor *output,
                                int kW, int kH,
                                int padW, int padH,
                                int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THCudaTensor_resize4d(state, output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *output_t = THCudaTensor_newSelect(state, output, 0, t);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor_cmul(state, finput2_t, finput2_t, finput2_t);
    THCudaTensor_sum(state, output_t, finput2_t, 0, 0);

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, output_t);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
  }

  return 1;
}

int cost_volume_l2_backward_cuda(THCudaTensor *input1,
                                    THCudaTensor *input2,
                                    THCudaTensor *grad_output, 
                                    THCudaTensor *grad_input1, 
                                    THCudaTensor *grad_input2,
                                    int kW, int kH,
                                    int padW, int padH,
                                    int dilationW, int dilationH)
{
  THCudaTensor_resizeAs(state, grad_input1, input1);
  THCudaTensor_resizeAs(state, grad_input2, input2);
  THCudaTensor_fill(state, grad_input1, 0.0);
  THCudaTensor_fill(state, grad_input2, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *grad_output_t = THCudaTensor_newSelect(state, grad_output, 0, t);
    THCudaTensor *grad_input1_t = THCudaTensor_newSelect(state, grad_input1, 0, t);
    THCudaTensor *grad_input2_t = THCudaTensor_newSelect(state, grad_input2, 0, t);

    // grad_input1
    THCudaTensor *fgrad_output_t_expand = THCudaTensor_newWithStorage3d(state,
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor *fgrad_input1_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_copy(state, fgrad_input1_t, finput2_t);
    THCudaTensor_mul(state, fgrad_input1_t, fgrad_input1_t, 2.0);
    THCudaTensor_cmul(state, fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);

    THCudaTensor *fgrad_input1_t_sum = THCudaTensor_newWithSize2d(state, nInputPlane, inputHeight*inputWidth);
    THCudaTensor_sum(state, fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THCudaTensor_resize3d(state, fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THCudaTensor_copy(state, grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THCudaTensor_neg(state, fgrad_input1_t, fgrad_input1_t);

    col2im_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, grad_input2_t)
    );

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_input1_t);
    THCudaTensor_free(state, grad_input2_t);
    THCudaTensor_free(state, fgrad_output_t_expand);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
    THCudaTensor_free(state, fgrad_input1_t);
    THCudaTensor_free(state, fgrad_input1_t_sum);
  }

  return 1;
}


int cost_volume_l1_forward_cuda(THCudaTensor *input1, 
                                THCudaTensor *input2,
                                THCudaTensor *output,
                                int kW, int kH,
                                int padW, int padH,
                                int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THCudaTensor_resize4d(state, output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *output_t = THCudaTensor_newSelect(state, output, 0, t);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor_abs(state, finput2_t, finput2_t);
    THCudaTensor_sum(state, output_t, finput2_t, 0, 0);

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, output_t);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
  }

  return 1;
}

int cost_volume_l1_backward_cuda(THCudaTensor *input1,
                                    THCudaTensor *input2,
                                    THCudaTensor *grad_output, 
                                    THCudaTensor *grad_input1, 
                                    THCudaTensor *grad_input2,
                                    int kW, int kH,
                                    int padW, int padH,
                                    int dilationW, int dilationH)
{
  THCudaTensor_resizeAs(state, grad_input1, input1);
  THCudaTensor_resizeAs(state, grad_input2, input2);
  THCudaTensor_fill(state, grad_input1, 0.0);
  THCudaTensor_fill(state, grad_input2, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *grad_output_t = THCudaTensor_newSelect(state, grad_output, 0, t);
    THCudaTensor *grad_input1_t = THCudaTensor_newSelect(state, grad_input1, 0, t);
    THCudaTensor *grad_input2_t = THCudaTensor_newSelect(state, grad_input2, 0, t);

    // grad_input1
    THCudaTensor *fgrad_output_t_expand = THCudaTensor_newWithStorage3d(state,
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor *fgrad_input1_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_sign(state, fgrad_input1_t, finput2_t);
    THCudaTensor_cmul(state, fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);

    THCudaTensor *fgrad_input1_t_sum = THCudaTensor_newWithSize2d(state, nInputPlane, inputHeight*inputWidth);
    THCudaTensor_sum(state, fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THCudaTensor_resize3d(state, fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THCudaTensor_copy(state, grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THCudaTensor_neg(state, fgrad_input1_t, fgrad_input1_t);

    col2im_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, grad_input2_t)
    );

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_input1_t);
    THCudaTensor_free(state, grad_input2_t);
    THCudaTensor_free(state, fgrad_output_t_expand);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
    THCudaTensor_free(state, fgrad_input1_t);
    THCudaTensor_free(state, fgrad_input1_t_sum);
  }

  return 1;
}


int deform_cost_volume_l1_forward_cuda(THCudaTensor *input1, 
                                       THCudaTensor *input2,
                                       THCudaTensor *flow,
                                       THCudaTensor *output,
                                       int kW, int kH,
                                       int padW, int padH,
                                       int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THCudaTensor_resize4d(state, output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *flow_t   = THCudaTensor_newSelect(state, flow, 0, t);
    THCudaTensor *output_t = THCudaTensor_newSelect(state, output, 0, t);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col_flow_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      THCudaTensor_data(state, flow_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor_abs(state, finput2_t, finput2_t);
    THCudaTensor_sum(state, output_t, finput2_t, 0, 0);

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, flow_t);
    THCudaTensor_free(state, output_t);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
  }

  return 1;
}

int deform_cost_volume_l1_backward_cuda(THCudaTensor *input1,
                                        THCudaTensor *input2,
                                        THCudaTensor *flow,
                                        THCudaTensor *grad_output, 
                                        THCudaTensor *grad_input1, 
                                        THCudaTensor *grad_input2,
                                        THCudaTensor *grad_flow,
                                        int kW, int kH,
                                        int padW, int padH,
                                        int dilationW, int dilationH,
                                        int updateGradFlow)
{
  THCudaTensor_resizeAs(state, grad_input1, input1);
  THCudaTensor_resizeAs(state, grad_input2, input2);
  THCudaTensor_resizeAs(state, grad_flow, flow);
  THCudaTensor_fill(state, grad_input1, 0.0);
  THCudaTensor_fill(state, grad_input2, 0.0);
  THCudaTensor_fill(state, grad_flow, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {

    THCudaTensor *input1_t = THCudaTensor_newSelect(state, input1, 0, t);
    THCudaTensor *input2_t = THCudaTensor_newSelect(state, input2, 0, t);
    THCudaTensor *flow_t = THCudaTensor_newSelect(state, flow, 0, t);
    THCudaTensor *grad_output_t = THCudaTensor_newSelect(state, grad_output, 0, t);
    THCudaTensor *grad_input1_t = THCudaTensor_newSelect(state, grad_input1, 0, t);
    THCudaTensor *grad_input2_t = THCudaTensor_newSelect(state, grad_input2, 0, t);
    THCudaTensor *grad_flow_t = THCudaTensor_newSelect(state, grad_flow, 0, t);

    // grad_input1
    THCudaTensor *fgrad_output_t_expand = THCudaTensor_newWithStorage3d(state,
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THCudaTensor *input1_t_expand = THCudaTensor_newWithStorage3d(state,
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THCudaTensor *finput2_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_flow_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      THCudaTensor_data(state, flow_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THCudaTensor_data(state, finput2_t)
    );

    THCudaTensor_resize3d(state, finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_cadd(state, finput2_t, input1_t_expand, -1.0, finput2_t);

    THCudaTensor *fgrad_input1_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
    THCudaTensor_sign(state, fgrad_input1_t, finput2_t);
    THCudaTensor_cmul(state, fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);

    THCudaTensor *fgrad_input1_t_sum = THCudaTensor_newWithSize2d(state, nInputPlane, inputHeight*inputWidth);
    THCudaTensor_sum(state, fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THCudaTensor_resize3d(state, fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THCudaTensor_copy(state, grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THCudaTensor_neg(state, fgrad_input1_t, fgrad_input1_t);

    col2im_flow_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, input2_t),
      THCudaTensor_data(state, flow_t),
      THCudaTensor_data(state, fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW, updateGradFlow,
      THCudaTensor_data(state, grad_input2_t),
      THCudaTensor_data(state, grad_flow_t)
    );

    THCudaTensor_free(state, input1_t);
    THCudaTensor_free(state, input2_t);
    THCudaTensor_free(state, flow_t);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_input1_t);
    THCudaTensor_free(state, grad_input2_t);
    THCudaTensor_free(state, grad_flow_t);
    THCudaTensor_free(state, fgrad_output_t_expand);
    THCudaTensor_free(state, input1_t_expand);
    THCudaTensor_free(state, finput2_t);
    THCudaTensor_free(state, fgrad_input1_t);
    THCudaTensor_free(state, fgrad_input1_t_sum);
  }

  return 1;
}
