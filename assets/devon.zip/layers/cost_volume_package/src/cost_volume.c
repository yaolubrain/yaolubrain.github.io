#include <TH/TH.h>
#include "im2col.h"

int cost_volume_dotprod_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THFloatTensor_resize4d(output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *output_t = THFloatTensor_newSelect(output, 0, t);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cmul(finput2_t, input1_t_expand, finput2_t);
    THFloatTensor_sum(output_t, finput2_t, 0, 0);

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(output_t);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
  }

  return 1;
}

int cost_volume_dotprod_backward(THFloatTensor *input1,
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH)
{
  THFloatTensor_resizeAs(grad_input1, input1);
  THFloatTensor_resizeAs(grad_input2, input2);
  THFloatTensor_fill(grad_input1, 0.0);
  THFloatTensor_fill(grad_input2, 0.0);


  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *grad_output_t = THFloatTensor_newSelect(grad_output, 0, t);
    THFloatTensor *grad_input1_t = THFloatTensor_newSelect(grad_input1, 0, t);
    THFloatTensor *grad_input2_t = THFloatTensor_newSelect(grad_input2, 0, t);

    // grad_input1
    THFloatTensor *fgrad_output_t_expand = THFloatTensor_newWithStorage3d(
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);


    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);

    THFloatTensor *fgrad_input1_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cmul(fgrad_input1_t, finput2_t, fgrad_output_t_expand);

    THFloatTensor *fgrad_input1_t_sum = THFloatTensor_newWithSize2d(nInputPlane, inputHeight*inputWidth);
    THFloatTensor_sum(fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THFloatTensor_resize3d(fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THFloatTensor_copy(grad_input1_t, fgrad_input1_t_sum);

    // grad_input2
    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *fgrad_input2_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cmul(fgrad_input2_t, input1_t_expand, fgrad_output_t_expand);

    col2im(
      THFloatTensor_data(fgrad_input2_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(grad_input2_t)
    );

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_input1_t);
    THFloatTensor_free(grad_input2_t);
    THFloatTensor_free(fgrad_output_t_expand);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
    THFloatTensor_free(fgrad_input1_t);
    THFloatTensor_free(fgrad_input1_t_sum);
    THFloatTensor_free(fgrad_input2_t);
  }

  return 1;
}


int cost_volume_l1_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THFloatTensor_resize4d(output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *output_t = THFloatTensor_newSelect(output, 0, t);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor_abs(finput2_t, finput2_t);
    THFloatTensor_sum(output_t, finput2_t, 0, 0);

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(output_t);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
  }

  return 1;
}

int cost_volume_l1_backward(THFloatTensor *input1,
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH)
{
  THFloatTensor_resizeAs(grad_input1, input1);
  THFloatTensor_resizeAs(grad_input2, input2);
  THFloatTensor_fill(grad_input1, 0.0);
  THFloatTensor_fill(grad_input2, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *grad_output_t = THFloatTensor_newSelect(grad_output, 0, t);
    THFloatTensor *grad_input1_t = THFloatTensor_newSelect(grad_input1, 0, t);
    THFloatTensor *grad_input2_t = THFloatTensor_newSelect(grad_input2, 0, t);

    // grad_input1
    THFloatTensor *fgrad_output_t_expand = THFloatTensor_newWithStorage3d(
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor *fgrad_input1_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_sign(fgrad_input1_t, finput2_t);
    THFloatTensor_cmul(fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);

    THFloatTensor *fgrad_input1_t_sum = THFloatTensor_newWithSize2d(nInputPlane, inputHeight*inputWidth);
    THFloatTensor_sum(fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THFloatTensor_resize3d(fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THFloatTensor_copy(grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THFloatTensor_neg(fgrad_input1_t, fgrad_input1_t);

    col2im(
      THFloatTensor_data(fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(grad_input2_t)
    );

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_input1_t);
    THFloatTensor_free(grad_input2_t);
    THFloatTensor_free(fgrad_output_t_expand);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
    THFloatTensor_free(fgrad_input1_t);
    THFloatTensor_free(fgrad_input1_t_sum);
  }

  return 1;
}


int cost_volume_l2_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THFloatTensor_resize4d(output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *output_t = THFloatTensor_newSelect(output, 0, t);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor_cmul(finput2_t, finput2_t, finput2_t);
    THFloatTensor_sum(output_t, finput2_t, 0, 0);

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(output_t);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
  }

  return 1;
}

int cost_volume_l2_backward(THFloatTensor *input1,
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH)
{
  THFloatTensor_resizeAs(grad_input1, input1);
  THFloatTensor_resizeAs(grad_input2, input2);
  THFloatTensor_fill(grad_input1, 0.0);
  THFloatTensor_fill(grad_input2, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *grad_output_t = THFloatTensor_newSelect(grad_output, 0, t);
    THFloatTensor *grad_input1_t = THFloatTensor_newSelect(grad_input1, 0, t);
    THFloatTensor *grad_input2_t = THFloatTensor_newSelect(grad_input2, 0, t);

    // grad_input1
    THFloatTensor *fgrad_output_t_expand = THFloatTensor_newWithStorage3d(
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col(
      THFloatTensor_data(input2_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor *fgrad_input1_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_copy(fgrad_input1_t, finput2_t);
    THFloatTensor_cmul(fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);
    THFloatTensor_mul(fgrad_input1_t, fgrad_input1_t, 2.0);

    THFloatTensor *fgrad_input1_t_sum = THFloatTensor_newWithSize2d(nInputPlane, inputHeight*inputWidth);
    THFloatTensor_sum(fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THFloatTensor_resize3d(fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THFloatTensor_copy(grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THFloatTensor_neg(fgrad_input1_t, fgrad_input1_t);

    col2im(
      THFloatTensor_data(fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(grad_input2_t)
    );

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_input1_t);
    THFloatTensor_free(grad_input2_t);
    THFloatTensor_free(fgrad_output_t_expand);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
    THFloatTensor_free(fgrad_input1_t);
    THFloatTensor_free(fgrad_input1_t_sum);
  }

  return 1;
}





int deform_cost_volume_l1_forward(THFloatTensor *input1, 
                                     THFloatTensor *input2,
                                     THFloatTensor *flow,
                                     THFloatTensor *output,
                                     int kW, int kH,
                                     int padW, int padH,
                                     int dilationW, int dilationH)
{
  int T = input1->size[0];
  int nInputPlane = input1->size[1];
  int inputWidth  = input1->size[3];
  int inputHeight = input1->size[2];

  THFloatTensor_resize4d(output, T, kW*kH, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *flow_t   = THFloatTensor_newSelect(flow, 0, t);
    THFloatTensor *output_t = THFloatTensor_newSelect(output, 0, t);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);
  
    im2col_flow(
      THFloatTensor_data(input2_t),
      THFloatTensor_data(flow_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor_abs(finput2_t, finput2_t);
    THFloatTensor_sum(output_t, finput2_t, 0, 0);

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(flow_t);
    THFloatTensor_free(output_t);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
  }

  return 1;
}

int deform_cost_volume_l1_backward(THFloatTensor *input1,
                                   THFloatTensor *input2,
                                   THFloatTensor *flow,
                                   THFloatTensor *grad_output, 
                                   THFloatTensor *grad_input1, 
                                   THFloatTensor *grad_input2,
                                   THFloatTensor *grad_flow,
                                   int kW, int kH,
                                   int padW, int padH,
                                   int dilationW, int dilationH,
                                   int updateGradFlow)
{
  THFloatTensor_resizeAs(grad_input1, input1);
  THFloatTensor_resizeAs(grad_input2, input2);
  THFloatTensor_resizeAs(grad_flow, flow);
  THFloatTensor_fill(grad_input1, 0.0);
  THFloatTensor_fill(grad_input2, 0.0);
  THFloatTensor_fill(grad_flow, 0.0);

  int nInputPlane  = input1->size[1];
  int inputWidth   = input1->size[3];
  int inputHeight  = input1->size[2];
  int T = input1->size[0];

  int t;
  for (t = 0; t < T; t++) {

    THFloatTensor *input1_t = THFloatTensor_newSelect(input1, 0, t);
    THFloatTensor *input2_t = THFloatTensor_newSelect(input2, 0, t);
    THFloatTensor *flow_t = THFloatTensor_newSelect(flow, 0, t);
    THFloatTensor *grad_output_t = THFloatTensor_newSelect(grad_output, 0, t);
    THFloatTensor *grad_input1_t = THFloatTensor_newSelect(grad_input1, 0, t);
    THFloatTensor *grad_input2_t = THFloatTensor_newSelect(grad_input2, 0, t);
    THFloatTensor *grad_flow_t = THFloatTensor_newSelect(grad_flow, 0, t);

    // grad_input1
    THFloatTensor *fgrad_output_t_expand = THFloatTensor_newWithStorage3d(
                                               grad_output_t->storage, 
                                               grad_output_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THFloatTensor *input1_t_expand = THFloatTensor_newWithStorage3d(
                                         input1_t->storage, 
                                         input1_t->storageOffset,
                                         nInputPlane, inputHeight*inputWidth,
                                         kW*kH, 0,
                                         inputHeight*inputWidth, 1);

    THFloatTensor *finput2_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_flow(
      THFloatTensor_data(input2_t),
      THFloatTensor_data(flow_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, 1, 1,
      dilationH, dilationW,
      THFloatTensor_data(finput2_t)
    );

    THFloatTensor_resize3d(finput2_t, nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_cadd(finput2_t, input1_t_expand, -1.0, finput2_t);

    THFloatTensor *fgrad_input1_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
    THFloatTensor_sign(fgrad_input1_t, finput2_t);
    THFloatTensor_cmul(fgrad_input1_t, fgrad_input1_t, fgrad_output_t_expand);

    THFloatTensor *fgrad_input1_t_sum = THFloatTensor_newWithSize2d(nInputPlane, inputHeight*inputWidth);
    THFloatTensor_sum(fgrad_input1_t_sum, fgrad_input1_t, 1, 0);
    THFloatTensor_resize3d(fgrad_input1_t_sum, nInputPlane, inputHeight, inputWidth);
    THFloatTensor_copy(grad_input1_t, fgrad_input1_t_sum);

    // grad_input2:  fgrad_input2_t = - fgrad_input1_t

    THFloatTensor_neg(fgrad_input1_t, fgrad_input1_t);

    col2im_flow(
      THFloatTensor_data(input2_t),
      THFloatTensor_data(flow_t),
      THFloatTensor_data(fgrad_input1_t),
      nInputPlane, inputHeight, inputWidth,
      kH, kW, padH, padW, 1, 1,
      dilationH, dilationW, updateGradFlow,
      THFloatTensor_data(grad_input2_t),
      THFloatTensor_data(grad_flow_t)
    );

    THFloatTensor_free(input1_t);
    THFloatTensor_free(input2_t);
    THFloatTensor_free(flow_t);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_input1_t);
    THFloatTensor_free(grad_input2_t);
    THFloatTensor_free(grad_flow_t);
    THFloatTensor_free(fgrad_output_t_expand);
    THFloatTensor_free(input1_t_expand);
    THFloatTensor_free(finput2_t);
    THFloatTensor_free(fgrad_input1_t);
    THFloatTensor_free(fgrad_input1_t_sum);
  }

  return 1;
}
