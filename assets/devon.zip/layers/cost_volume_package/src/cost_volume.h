int cost_volume_dotprod_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH);

int cost_volume_dotprod_backward(THFloatTensor *input1, 
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH); 


int cost_volume_l1_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH);

int cost_volume_l1_backward(THFloatTensor *input1, 
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH); 

int cost_volume_l2_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH);

int cost_volume_l2_backward(THFloatTensor *input1, 
                               THFloatTensor *input2,
                               THFloatTensor *grad_output, 
                               THFloatTensor *grad_input1, 
                               THFloatTensor *grad_input2,
                               int kW, int kH,
                               int padW, int padH,
                               int dilationW, int dilationH); 


int deform_cost_volume_l1_forward(THFloatTensor *input1, 
                              THFloatTensor *input2,
                              THFloatTensor *flow,
                              THFloatTensor *output,
                              int kW, int kH,
                              int padW, int padH,
                              int dilationW, int dilationH);

int deform_cost_volume_l1_backward(THFloatTensor *input1, 
                                   THFloatTensor *input2,
                                   THFloatTensor *flow,
                                   THFloatTensor *grad_output, 
                                   THFloatTensor *grad_input1, 
                                   THFloatTensor *grad_input2,
                                   THFloatTensor *grad_flow,
                                   int kW, int kH,
                                   int padW, int padH,
                                   int dilationW, int dilationH,
                                   int updateGradFlow); 
