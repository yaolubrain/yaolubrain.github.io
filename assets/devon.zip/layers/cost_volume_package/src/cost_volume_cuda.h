int cost_volume_dotprod_forward_cuda(THCudaTensor *input1, 
                                     THCudaTensor *input2,
                                     THCudaTensor *output,
                                     int kW, int kH,
                                     int padW, int padH,
                                     int dilationW, int dilationH);

int cost_volume_dotprod_backward_cuda(THCudaTensor *input1, 
                                      THCudaTensor *input2,
                                      THCudaTensor *grad_output, 
                                      THCudaTensor *grad_input1, 
                                      THCudaTensor *grad_input2,
                                      int kW, int kH,
                                      int padW, int padH,
                                      int dilationW, int dilationH); 


int cost_volume_l1_forward_cuda(THCudaTensor *input1, 
                                THCudaTensor *input2,
                                THCudaTensor *output,
                                int kW, int kH,
                                int padW, int padH,
                                int dilationW, int dilationH);

int cost_volume_l1_backward_cuda(THCudaTensor *input1, 
                                 THCudaTensor *input2,
                                 THCudaTensor *grad_output, 
                                 THCudaTensor *grad_input1, 
                                 THCudaTensor *grad_input2,
                                 int kW, int kH,
                                 int padW, int padH,
                                 int dilationW, int dilationH); 

int cost_volume_l2_forward_cuda(THCudaTensor *input1, 
                                THCudaTensor *input2,
                                THCudaTensor *output,
                                int kW, int kH,
                                int padW, int padH,
                                int dilationW, int dilationH);

int cost_volume_l2_backward_cuda(THCudaTensor *input1, 
                                 THCudaTensor *input2,
                                 THCudaTensor *grad_output, 
                                 THCudaTensor *grad_input1, 
                                 THCudaTensor *grad_input2,
                                 int kW, int kH,
                                 int padW, int padH,
                                 int dilationW, int dilationH); 


int deform_cost_volume_l1_forward_cuda(THCudaTensor *input1, 
                                       THCudaTensor *input2,
                                       THCudaTensor *flow,
                                       THCudaTensor *output,
                                       int kW, int kH,
                                       int padW, int padH,
                                       int dilationW, int dilationH);

int deform_cost_volume_l1_backward_cuda(THCudaTensor *input1, 
                                        THCudaTensor *input2,
                                        THCudaTensor *flow,
                                        THCudaTensor *grad_output, 
                                        THCudaTensor *grad_input1, 
                                        THCudaTensor *grad_input2,
                                        THCudaTensor *grad_flow,
                                        int kW, int kH,
                                        int padW, int padH,
                                        int dilationW, int dilationH,
                                        int updateGradFlow); 
