import torch
from torch.autograd import Function, Variable
from .._ext import cost_volume

class CostVolumeDotProdFunction(Function):

    @staticmethod
    def forward(ctx, input1, input2, ksize_h, ksize_w, pad_h, pad_w, dilation_h, dilation_w):
        ctx.save_for_backward(input1, input2)
        ctx.ksize_h = ksize_h
        ctx.ksize_w = ksize_w
        ctx.pad_h = pad_h
        ctx.pad_w = pad_w 
        ctx.dilation_h = dilation_h
        ctx.dilation_w = dilation_w

        output = input1.new()

        if not input1.is_cuda:
            cost_volume.cost_volume_dotprod_forward(input1, input2, output, \
                                            ksize_h, ksize_w, \
                                            pad_h, pad_w, \
                                            dilation_h, dilation_w)
        else:
            cost_volume.cost_volume_dotprod_forward_cuda(input1, input2, output, \
                                                 ksize_h, ksize_w, \
                                                 pad_h, pad_w, \
                                                 dilation_h, dilation_w)
        return output


    @staticmethod
    def backward(ctx, grad_output):
        input1, input2 = ctx.saved_variables

        grad_input1 = input1.data.new()
        grad_input2 = input2.data.new()

        if not grad_output.is_cuda:
            cost_volume.cost_volume_dotprod_backward(input1.data, input2.data, grad_output.data,  \
                                                   grad_input1, grad_input2, \
                                                   ctx.ksize_h, ctx.ksize_w, \
                                                   ctx.pad_h, ctx.pad_w, \
                                                   ctx.dilation_h, ctx.dilation_w)
        else:
            cost_volume.cost_volume_dotprod_backward_cuda(input1.data, input2.data, grad_output.data, \
                                                        grad_input1, grad_input2, \
                                                        ctx.ksize_h, ctx.ksize_w, \
                                                        ctx.pad_h, ctx.pad_w, \
                                                        ctx.dilation_h, ctx.dilation_w)

        return Variable(grad_input1), Variable(grad_input2), None, None, None, None, None, None


class CostVolumeL1Function(Function):

    @staticmethod
    def forward(ctx, input1, input2, ksize_h, ksize_w, pad_h, pad_w, dilation_h, dilation_w):
        ctx.save_for_backward(input1, input2)
        ctx.ksize_h = ksize_h
        ctx.ksize_w = ksize_w
        ctx.pad_h = pad_h
        ctx.pad_w = pad_w 
        ctx.dilation_h = dilation_h
        ctx.dilation_w = dilation_w

        output = input1.new()

        if not input1.is_cuda:
            cost_volume.cost_volume_l1_forward(input1, input2, output, \
                                            ksize_h, ksize_w, \
                                            pad_h, pad_w, \
                                            dilation_h, dilation_w)
        else:
            cost_volume.cost_volume_l1_forward_cuda(input1, input2, output, \
                                                 ksize_h, ksize_w, \
                                                 pad_h, pad_w, \
                                                 dilation_h, dilation_w)
        return output


    @staticmethod
    def backward(ctx, grad_output):
        input1, input2 = ctx.saved_variables

        grad_input1 = input1.data.new()
        grad_input2 = input2.data.new()

        if not grad_output.is_cuda:
            cost_volume.cost_volume_l1_backward(input1.data, input2.data, grad_output.data,  \
                                                   grad_input1, grad_input2, \
                                                   ctx.ksize_h, ctx.ksize_w, \
                                                   ctx.pad_h, ctx.pad_w, \
                                                   ctx.dilation_h, ctx.dilation_w)
        else:
            cost_volume.cost_volume_l1_backward_cuda(input1.data, input2.data, grad_output.data, \
                                                        grad_input1, grad_input2, \
                                                        ctx.ksize_h, ctx.ksize_w, \
                                                        ctx.pad_h, ctx.pad_w, \
                                                        ctx.dilation_h, ctx.dilation_w)

        return Variable(grad_input1), Variable(grad_input2), None, None, None, None, None, None


class CostVolumeL2Function(Function):

    @staticmethod
    def forward(ctx, input1, input2, ksize_h, ksize_w, pad_h, pad_w, dilation_h, dilation_w):
        ctx.save_for_backward(input1, input2)
        ctx.ksize_h = ksize_h
        ctx.ksize_w = ksize_w
        ctx.pad_h = pad_h
        ctx.pad_w = pad_w 
        ctx.dilation_h = dilation_h
        ctx.dilation_w = dilation_w

        output = input1.new()

        if not input1.is_cuda:
            cost_volume.cost_volume_l2_forward(input1, input2, output, \
                                            ksize_h, ksize_w, \
                                            pad_h, pad_w, \
                                            dilation_h, dilation_w)
        else:
            cost_volume.cost_volume_l2_forward_cuda(input1, input2, output, \
                                                 ksize_h, ksize_w, \
                                                 pad_h, pad_w, \
                                                 dilation_h, dilation_w)
        return output


    @staticmethod
    def backward(ctx, grad_output):
        input1, input2 = ctx.saved_variables

        grad_input1 = input1.data.new()
        grad_input2 = input2.data.new()

        if not grad_output.is_cuda:
            cost_volume.cost_volume_l2_backward(input1.data, input2.data, grad_output.data,  \
                                                   grad_input1, grad_input2, \
                                                   ctx.ksize_h, ctx.ksize_w, \
                                                   ctx.pad_h, ctx.pad_w, \
                                                   ctx.dilation_h, ctx.dilation_w)
        else:
            cost_volume.cost_volume_l2_backward_cuda(input1.data, input2.data, grad_output.data, \
                                                        grad_input1, grad_input2, \
                                                        ctx.ksize_h, ctx.ksize_w, \
                                                        ctx.pad_h, ctx.pad_w, \
                                                        ctx.dilation_h, ctx.dilation_w)

        return Variable(grad_input1), Variable(grad_input2), None, None, None, None, None, None


class DeformCostVolumeL1Function(Function):

    @staticmethod
    def forward(ctx, input1, input2, flow, ksize_h, ksize_w, pad_h, pad_w, dilation_h, dilation_w, updateGradFlow):
        ctx.save_for_backward(input1, input2, flow)
        ctx.ksize_h = ksize_h
        ctx.ksize_w = ksize_w
        ctx.pad_h = pad_h
        ctx.pad_w = pad_w 
        ctx.dilation_h = dilation_h
        ctx.dilation_w = dilation_w
        ctx.updateGradFlow = updateGradFlow

        output = input1.new()

        if not input1.is_cuda:
            cost_volume.deform_cost_volume_l1_forward(input1, input2, flow, output, \
                                            ksize_h, ksize_w, \
                                            pad_h, pad_w, \
                                            dilation_h, dilation_w)
        else:
            cost_volume.deform_cost_volume_l1_forward_cuda(input1, input2, flow, output, \
                                                 ksize_h, ksize_w, \
                                                 pad_h, pad_w, \
                                                 dilation_h, dilation_w)
        return output

    @staticmethod
    def backward(ctx, grad_output):
        input1, input2, flow = ctx.saved_variables

        grad_input1 = input1.data.new()
        grad_input2 = input2.data.new()
        grad_flow = flow.data.new()

        if not grad_output.is_cuda:
            cost_volume.deform_cost_volume_l1_backward(input1.data, input2.data, flow.data, grad_output.data,  \
                                                       grad_input1, grad_input2, grad_flow, \
                                                       ctx.ksize_h, ctx.ksize_w, \
                                                       ctx.pad_h, ctx.pad_w, \
                                                       ctx.dilation_h, ctx.dilation_w, ctx.updateGradFlow)
        else:
            cost_volume.deform_cost_volume_l1_backward_cuda(input1.data, input2.data, flow.data, grad_output.data, \
                                                            grad_input1, grad_input2, grad_flow, \
                                                            ctx.ksize_h, ctx.ksize_w, \
                                                            ctx.pad_h, ctx.pad_w, \
                                                            ctx.dilation_h, ctx.dilation_w, ctx.updateGradFlow)

        return Variable(grad_input1), Variable(grad_input2), Variable(grad_flow), None, None, None, None, None, None, None

