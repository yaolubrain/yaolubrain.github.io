import os
import torch
import torch.utils.ffi

strBasepath = os.path.split(os.path.abspath(__file__))[0] + '/'
strHeaders = ['src/cost_volume.h']
strSources = ['src/cost_volume.c']
strDefines = []
strObjects = []

if torch.cuda.is_available():
    print('Including CUDA code.')
    strHeaders += ['src/cost_volume_cuda.h']
    strSources += ['src/cost_volume_cuda.c']
    strDefines += [('WITH_CUDA', None)]
    strObjects += ['src/im2col_cuda.o']

print(strHeaders)

ffi = torch.utils.ffi.create_extension(
    name='_ext.cost_volume',
    headers=strHeaders,
    sources=strSources,
    verbose=True,
    with_cuda=True,
    package=False,
    relative_to=strBasepath,
    include_dirs=[os.path.expandvars('$CUDA_HOME') + '/include'],
    define_macros=strDefines,
    extra_objects=[os.path.join(strBasepath, strObject) for strObject in strObjects]
)

if __name__ == '__main__':
    ffi.build()



