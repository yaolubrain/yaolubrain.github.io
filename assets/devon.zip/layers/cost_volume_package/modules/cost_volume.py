from torch.nn.modules.module import Module
from ..functions.cost_volume import *

class CostVolumeDotProd(Module):
    def __init__(self, ksize_h=1, ksize_w=1, dilation_h=1, dilation_w=1):
        super().__init__()
        self.ksize_h = ksize_h
        self.ksize_w = ksize_w
        self.pad_h = int(ksize_h / 2) * dilation_h
        self.pad_w = int(ksize_w / 2) * dilation_w
        self.dilation_h = dilation_h
        self.dilation_w = dilation_w

    def forward(self, input1, input2):
        result = CostVolumeDotProdFunction.apply(input1, input2,  \
                                            self.ksize_h, self.ksize_w, \
                                            self.pad_h, self.pad_w,  \
                                            self.dilation_h, self.dilation_w)
        return result


class CostVolumeL1(Module):
    def __init__(self, ksize_h=1, ksize_w=1, dilation_h=1, dilation_w=1):
        super().__init__()
        self.ksize_h = ksize_h
        self.ksize_w = ksize_w
        self.pad_h = int(ksize_h / 2) * dilation_h
        self.pad_w = int(ksize_w / 2) * dilation_w
        self.dilation_h = dilation_h
        self.dilation_w = dilation_w

    def forward(self, input1, input2):
        result = CostVolumeL1Function.apply(input1, input2,  \
                                            self.ksize_h, self.ksize_w, \
                                            self.pad_h, self.pad_w,  \
                                            self.dilation_h, self.dilation_w)
        return result

class CostVolumeL2(Module):
    def __init__(self, ksize_h=1, ksize_w=1, dilation_h=1, dilation_w=1):
        super().__init__()
        self.ksize_h = ksize_h
        self.ksize_w = ksize_w
        self.pad_h = int(ksize_h / 2) * dilation_h
        self.pad_w = int(ksize_w / 2) * dilation_w
        self.dilation_h = dilation_h
        self.dilation_w = dilation_w

    def forward(self, input1, input2):
        result = CostVolumeL2Function.apply(input1, input2,  \
                                            self.ksize_h, self.ksize_w, \
                                            self.pad_h, self.pad_w,  \
                                            self.dilation_h, self.dilation_w)
        return result



class DeformCostVolumeL1(Module):
    def __init__(self, ksize_h=1, ksize_w=1, dilation_h=1, dilation_w=1, updateGradFlow=False):
        super().__init__()
        self.ksize_h = ksize_h
        self.ksize_w = ksize_w
        self.pad_h = int(ksize_h / 2) * dilation_h
        self.pad_w = int(ksize_w / 2) * dilation_w
        self.dilation_h = dilation_h
        self.dilation_w = dilation_w
        self.updateGradFlow = updateGradFlow

    def forward(self, input1, input2, flow):
        result = DeformCostVolumeL1Function.apply(input1, input2, flow, \
                                                  self.ksize_h, self.ksize_w, \
                                                  self.pad_h, self.pad_w,  \
                                                  self.dilation_h, self.dilation_w,\
                                                  self.updateGradFlow)
        return result

