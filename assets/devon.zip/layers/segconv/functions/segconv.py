import torch
from torch.autograd import Function, Variable
from .._ext import segconv

class SegConv2dFunction(Function):

    @staticmethod
    def forward(ctx, img, seg, weight, bias, kernel_size, stride, padding, dilation):
        ctx.save_for_backward(img, seg, weight, bias)
        ctx.kernel_size = kernel_size
        ctx.stride = stride
        ctx.padding = padding
        ctx.dilation = dilation

        output = img.new()

        if not img.is_cuda:
            segconv.segconv2d_forward_cpu(img, seg, output, 
                                          weight, bias,
                                          kernel_size, stride,
                                          padding, dilation)
        else:
            segconv.segconv2d_forward_gpu(img, seg, output, 
                                          weight, bias,
                                          kernel_size, stride,
                                          padding, dilation)
        return output


    @staticmethod
    def backward(ctx, grad_output):
        img, seg, weight, bias = ctx.saved_variables

        grad_img = img.data.new()
        grad_seg = seg.data.new()
        grad_weight = weight.data.new()
        grad_bias = bias.data.new()

        if not grad_output.is_cuda:
            segconv.segconv2d_backward_cpu(img.data, seg.data, 
                                           weight.data, bias.data,
                                           grad_output.data, grad_img, grad_seg, 
                                           grad_weight, grad_bias,
                                           ctx.kernel_size, ctx.stride,
                                           ctx.padding, ctx.dilation)
        else:
            segconv.segconv2d_backward_gpu(img.data, seg.data, 
                                           weight.data, bias.data,
                                           grad_output.data, grad_img, grad_seg, 
                                           grad_weight, grad_bias,
                                           ctx.kernel_size, ctx.stride,
                                           ctx.padding, ctx.dilation)


        grad_img = Variable(grad_img)
        grad_seg = Variable(grad_seg)      
        grad_weight = Variable(grad_weight)
        grad_bias = Variable(grad_bias)

        return grad_img, grad_seg, grad_weight, grad_bias, None, None, None, None

