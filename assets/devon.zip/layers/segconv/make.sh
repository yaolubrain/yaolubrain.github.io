#!/usr/bin/env bash
TORCH=$(python -c "import os; import torch; print(os.path.dirname(torch.__file__))")

cd src

rm -r ../_ext

echo "Compiling im2col_cuda by nvcc..."
nvcc -c -o im2col_gpu.o im2col_gpu.cu -x cu -Xcompiler -fPIC -arch=sm_52

cd ../
python build.py
