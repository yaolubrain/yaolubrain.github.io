import os
import torch
import torch.utils.ffi

strBasepath = os.path.split(os.path.abspath(__file__))[0] + '/'
strHeaders = ['src/segconv_cpu.h']
strSources = ['src/segconv_cpu.c']
strDefines = []
strObjects = []

if torch.cuda.is_available():
    print('Including CUDA code.')
    strHeaders += ['src/segconv_gpu.h']
    strSources += ['src/segconv_gpu.c']
    strDefines += [('WITH_CUDA', None)]
    strObjects += ['src/im2col_gpu.o']

print(strHeaders)

ffi = torch.utils.ffi.create_extension(
    name='_ext.segconv',
    headers=strHeaders,
    sources=strSources,
    verbose=True,
    with_cuda=True,
    package=False,
    relative_to=strBasepath,
    include_dirs=[os.path.expandvars('$CUDA_HOME') + '/include'],
    define_macros=strDefines,
    extra_objects=[os.path.join(strBasepath, strObject) for strObject in strObjects]
)

if __name__ == '__main__':
    ffi.build()



