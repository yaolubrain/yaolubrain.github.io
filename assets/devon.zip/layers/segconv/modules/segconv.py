import math
from torch.nn import Parameter
from torch.nn.modules.module import Module
from ..functions.segconv import *

class SegConv2d(Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, bias=True):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation

        self.weight = Parameter(torch.Tensor(out_channels, in_channels*kernel_size*kernel_size))

        self.bias = None
        if bias == True:
            self.bias = Parameter(torch.Tensor(out_channels))
 
        self.reset_parameters()


    def reset_parameters(self):
        n = self.in_channels * self.kernel_size**2
        stdv = 1. / math.sqrt(n)
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, img, seg):
        result = SegConv2dFunction.apply(img, seg, 
                                         self.weight, self.bias, 
                                         self.kernel_size, self.stride, 
                                         self.padding, self.dilation)
        return result



