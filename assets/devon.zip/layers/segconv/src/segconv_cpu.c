#include <TH/TH.h>
#include "im2col_cpu.h"

int segconv2d_forward_cpu(THFloatTensor *img, 
                          THFloatTensor *seg,
                          THFloatTensor *output,
                          THFloatTensor *weight,
                          THFloatTensor *bias,
                          int kernel_size, int stride,
                          int padding, int dilation)
{
  int T = img->size[0];
  int nInputPlane = img->size[1];
  int inputHeight = img->size[2];
  int inputWidth  = img->size[3];
  int nOutputPlane = weight->size[0];

  int kW = kernel_size;
  int kH = kernel_size;
  int strideW = 1;
  int strideH = 1;
  int padH = kernel_size / 2;
  int padW = kernel_size / 2;
  int dilationH = 1;
  int dilationW = 1;

  THFloatTensor_resize4d(output, T, nOutputPlane, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *img_t = THFloatTensor_newSelect(img, 0, t);
    THFloatTensor *seg_t = THFloatTensor_newSelect(seg, 0, t);
    THFloatTensor *output_t = THFloatTensor_newSelect(output, 0, t);


    if (bias) {
      THFloatTensor *bias_expand = THFloatTensor_newWithStorage3d(
                                               bias->storage, 
                                               bias->storageOffset,
                                               nOutputPlane, 1,
                                               inputHeight, 0,
                                               inputWidth, 0);
      THFloatTensor_copy(output_t, bias_expand);
    } else {
      THFloatTensor_zero(output_t);
    }
  
    THFloatTensor *img_cols_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col(
      THFloatTensor_data(img_t),
      nInputPlane, inputHeight, inputWidth, 
      kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THFloatTensor_data(img_cols_t)
    );

    THFloatTensor_resize3d(img_cols_t, nInputPlane, kW*kH, inputHeight*inputWidth);

    THFloatTensor *seg_t_expand = THFloatTensor_newWithStorage3d(
                                               seg_t->storage, 
                                               seg_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THFloatTensor_cmul(img_cols_t, img_cols_t, seg_t_expand);

    THFloatTensor_resize2d(img_cols_t, nInputPlane*kW*kH, inputHeight*inputWidth);

    THFloatTensor_resize2d(output_t, nOutputPlane, inputHeight*inputWidth);
    THFloatTensor_addmm(output_t, 1.0, output_t, 1.0, weight, img_cols_t);

    THFloatTensor_free(img_t);
    THFloatTensor_free(seg_t);
    THFloatTensor_free(output_t);
    THFloatTensor_free(img_cols_t);
    THFloatTensor_free(seg_t_expand);
  }

  return 1;
}

int segconv2d_backward_cpu(THFloatTensor *img,
                           THFloatTensor *seg,
                           THFloatTensor *weight,
                           THFloatTensor *bias,
                           THFloatTensor *grad_output, 
                           THFloatTensor *grad_img, 
                           THFloatTensor *grad_seg,
                           THFloatTensor *grad_weight,
                           THFloatTensor *grad_bias,
                           int kernel_size, int stride,
                           int padding, int dilation)
{
  THFloatTensor_resizeAs(grad_img, img);
  THFloatTensor_resizeAs(grad_seg, seg);
  THFloatTensor_resizeAs(grad_weight, weight);
  THFloatTensor_resizeAs(grad_bias, bias);
  THFloatTensor_fill(grad_img, 0.0);
  THFloatTensor_fill(grad_seg, 0.0);
  THFloatTensor_fill(grad_weight, 0.0);
  THFloatTensor_fill(grad_bias, 0.0);

  int T = img->size[0];
  int nInputPlane  = img->size[1];
  int inputHeight  = img->size[2];
  int inputWidth   = img->size[3];
  int nOutputPlane = grad_output->size[1];
  int outputHeight = grad_output->size[2];
  int outputWidth  = grad_output->size[3];

  int kW = kernel_size;
  int kH = kernel_size;
  int strideW = 1;
  int strideH = 1;
  int padH = kH / 2;
  int padW = kW / 2;
  int dilationH = 1;
  int dilationW = 1;

  THFloatTensor *weight_trans = THFloatTensor_newTranspose(weight, 0, 1);

  int t;
  for (t = 0; t < T; t++) {
    THFloatTensor *img_t = THFloatTensor_newSelect(img, 0, t);
    THFloatTensor *seg_t = THFloatTensor_newSelect(seg, 0, t);
    THFloatTensor *grad_output_t = THFloatTensor_newSelect(grad_output, 0, t);
    THFloatTensor *grad_img_t = THFloatTensor_newSelect(grad_img, 0, t);
    THFloatTensor *grad_seg_t = THFloatTensor_newSelect(grad_seg, 0, t);

    // grad_img
    THFloatTensor *buffer = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, outputHeight*outputWidth);
    THFloatTensor_resize2d(grad_output_t, nOutputPlane, outputHeight*outputWidth);
    THFloatTensor_addmm(buffer, 0.0, buffer, 1.0, weight_trans, grad_output_t);

    THFloatTensor *seg_t_expand = THFloatTensor_newWithStorage3d(
                                               seg_t->storage, 
                                               seg_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THFloatTensor *fgrad_img_t = THFloatTensor_newWithSize2d(nInputPlane*kW*kH, outputHeight*outputWidth);
    THFloatTensor_cmul(fgrad_img_t, buffer, seg_t_expand);

    col2im(
      THFloatTensor_data(fgrad_img_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THFloatTensor_data(grad_img_t)
    );


    // grad_seg
    THFloatTensor *img_cols_t = THFloatTensor_newWithSize3d(nInputPlane, kW*kH, inputHeight*inputWidth);
  
    im2col(
      THFloatTensor_data(img_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THFloatTensor_data(img_cols_t)
    );

    THFloatTensor_cmul(buffer, buffer, img_cols_t);
    THFloatTensor_resize3d(buffer, nInputPlane, kH*kW, outputHeight*outputWidth);
    THFloatTensor_sum(grad_seg_t, buffer, 0, 0);

    // grad_weight
    THFloatTensor_cmul(img_cols_t, seg_t_expand, img_cols_t);


    THFloatTensor_resize2d(img_cols_t, nInputPlane*kW*kH, inputHeight*inputWidth);
    THFloatTensor *img_cols_t_trans = THFloatTensor_newTranspose(img_cols_t, 0, 1);
    THFloatTensor_resize2d(grad_output_t, nOutputPlane, inputHeight*inputWidth);

    THFloatTensor_addmm(grad_weight, 1.0, grad_weight, 1.0, grad_output_t, img_cols_t_trans);

    // grad_bias
    THFloatTensor *grad_output_t_sum = THFloatTensor_newWithSize1d(nOutputPlane);
    THFloatTensor_sum(grad_output_t_sum, grad_output_t, 1, 0);
    THFloatTensor_cadd(grad_bias, grad_bias, 1.0, grad_output_t_sum);

    THFloatTensor_free(img_t);
    THFloatTensor_free(seg_t);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_img_t);
    THFloatTensor_free(grad_seg_t);
    THFloatTensor_free(buffer);
    THFloatTensor_free(seg_t_expand);
    THFloatTensor_free(fgrad_img_t);
    THFloatTensor_free(img_cols_t);
    THFloatTensor_free(img_cols_t_trans);
    THFloatTensor_free(grad_output_t);
    THFloatTensor_free(grad_output_t_sum);
  }

  return 1;
}

