#include <THC/THC.h>
#include "im2col_gpu.h"

// this symbol will be resolved automatically from PyTorch libs
extern THCState *state;


int segconv2d_forward_gpu(THCudaTensor *img, 
                          THCudaTensor *seg,
                          THCudaTensor *output,
                          THCudaTensor *weight,
                          THCudaTensor *bias,
                          int kernel_size, int stride,
                          int padding, int dilation)
{
  int T = img->size[0];
  int nInputPlane = img->size[1];
  int inputHeight = img->size[2];
  int inputWidth  = img->size[3];
  int nOutputPlane = weight->size[0];

  int kW = kernel_size;
  int kH = kernel_size;
  int strideW = 1;
  int strideH = 1;
  int padH = kernel_size / 2;
  int padW = kernel_size / 2;
  int dilationH = 1;
  int dilationW = 1;

  THCudaTensor_resize4d(state, output, T, nOutputPlane, inputHeight, inputWidth);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *img_t = THCudaTensor_newSelect(state, img, 0, t);
    THCudaTensor *seg_t = THCudaTensor_newSelect(state, seg, 0, t);
    THCudaTensor *output_t = THCudaTensor_newSelect(state, output, 0, t);

    if (bias) {
      THCudaTensor *bias_expand = THCudaTensor_newWithStorage3d(state,
                                               bias->storage, 
                                               bias->storageOffset,
                                               nOutputPlane, 1,
                                               inputHeight, 0,
                                               inputWidth, 0);
      THCudaTensor_copy(state, output_t, bias_expand);
    } else {
      THCudaTensor_zero(state, output_t);
    }
  
    THCudaTensor *img_cols_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, inputHeight*inputWidth);

    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, img_t),
      nInputPlane, inputHeight, inputWidth, 
      kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THCudaTensor_data(state, img_cols_t)
    );

    THCudaTensor_resize3d(state, img_cols_t, nInputPlane, kW*kH, inputHeight*inputWidth);

    THCudaTensor *seg_t_expand = THCudaTensor_newWithStorage3d(state,
                                               seg_t->storage, 
                                               seg_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THCudaTensor_cmul(state, img_cols_t, img_cols_t, seg_t_expand);

    THCudaTensor_resize2d(state, img_cols_t, nInputPlane*kW*kH, inputHeight*inputWidth);

    THCudaTensor_resize2d(state, output_t, nOutputPlane, inputHeight*inputWidth);
    THCudaTensor_addmm(state, output_t, 1.0, output_t, 1.0, weight, img_cols_t);

    THCudaTensor_free(state, img_t);
    THCudaTensor_free(state, seg_t);
    THCudaTensor_free(state, output_t);
    THCudaTensor_free(state, img_cols_t);
    THCudaTensor_free(state, seg_t_expand);
  }

  return 1;
}

int segconv2d_backward_gpu(THCudaTensor *img,
                           THCudaTensor *seg,
                           THCudaTensor *weight,
                           THCudaTensor *bias,
                           THCudaTensor *grad_output, 
                           THCudaTensor *grad_img, 
                           THCudaTensor *grad_seg,
                           THCudaTensor *grad_weight,
                           THCudaTensor *grad_bias,
                           int kernel_size, int stride,
                           int padding, int dilation)
{
  THCudaTensor_resizeAs(state, grad_img, img);
  THCudaTensor_resizeAs(state, grad_seg, seg);
  THCudaTensor_resizeAs(state, grad_weight, weight);
  THCudaTensor_resizeAs(state, grad_bias, bias);
  THCudaTensor_fill(state, grad_img, 0.0);
  THCudaTensor_fill(state, grad_seg, 0.0);
  THCudaTensor_fill(state, grad_weight, 0.0);
  THCudaTensor_fill(state, grad_bias, 0.0);

  int T = img->size[0];
  int nInputPlane  = img->size[1];
  int inputHeight  = img->size[2];
  int inputWidth   = img->size[3];
  int nOutputPlane = grad_output->size[1];
  int outputHeight = grad_output->size[2];
  int outputWidth  = grad_output->size[3];

  int kW = kernel_size;
  int kH = kernel_size;
  int strideW = 1;
  int strideH = 1;
  int padH = kH / 2;
  int padW = kW / 2;
  int dilationH = 1;
  int dilationW = 1;

  THCudaTensor *weight_trans = THCudaTensor_newTranspose(state, weight, 0, 1);

  int t;
  for (t = 0; t < T; t++) {
    THCudaTensor *img_t = THCudaTensor_newSelect(state, img, 0, t);
    THCudaTensor *seg_t = THCudaTensor_newSelect(state, seg, 0, t);
    THCudaTensor *grad_output_t = THCudaTensor_newSelect(state, grad_output, 0, t);
    THCudaTensor *grad_img_t = THCudaTensor_newSelect(state, grad_img, 0, t);
    THCudaTensor *grad_seg_t = THCudaTensor_newSelect(state, grad_seg, 0, t);

    // grad_img
    THCudaTensor *buffer = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, outputHeight*outputWidth);
    THCudaTensor_resize2d(state, grad_output_t, nOutputPlane, outputHeight*outputWidth);
    THCudaTensor_addmm(state, buffer, 0.0, buffer, 1.0, weight_trans, grad_output_t);

    THCudaTensor *seg_t_expand = THCudaTensor_newWithStorage3d(state,
                                               seg_t->storage, 
                                               seg_t->storageOffset,
                                               nInputPlane, 0,
                                               kW*kH, inputHeight*inputWidth,
                                               inputHeight*inputWidth, 1);

    THCudaTensor *fgrad_img_t = THCudaTensor_newWithSize2d(state, nInputPlane*kW*kH, outputHeight*outputWidth);
    THCudaTensor_cmul(state, fgrad_img_t, buffer, seg_t_expand);

    col2im_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, fgrad_img_t),
      nInputPlane, inputHeight, inputWidth,
      inputHeight, inputWidth,
      kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THCudaTensor_data(state, grad_img_t)
    );


    // grad_seg
    THCudaTensor *img_cols_t = THCudaTensor_newWithSize3d(state, nInputPlane, kW*kH, inputHeight*inputWidth);
  
    im2col_cuda(
      THCState_getCurrentStream(state),
      THCudaTensor_data(state, img_t),
      nInputPlane, inputHeight, inputWidth, kH, kW, padH, padW, strideH, strideW,
      dilationH, dilationW,
      THCudaTensor_data(state, img_cols_t)
    );

    THCudaTensor_cmul(state, buffer, buffer, img_cols_t);
    THCudaTensor_resize3d(state, buffer, nInputPlane, kH*kW, outputHeight*outputWidth);
    THCudaTensor_sum(state, grad_seg_t, buffer, 0, 0);

    // grad_weight
    THCudaTensor_cmul(state, img_cols_t, seg_t_expand, img_cols_t);

    THCudaTensor_resize2d(state, img_cols_t, nInputPlane*kW*kH, inputHeight*inputWidth);
    THCudaTensor *img_cols_t_trans = THCudaTensor_newTranspose(state, img_cols_t, 0, 1);
    THCudaTensor_resize2d(state, grad_output_t, nOutputPlane, inputHeight*inputWidth);

    THCudaTensor_addmm(state, grad_weight, 1.0, grad_weight, 1.0, grad_output_t, img_cols_t_trans);

    // grad_bias
    THCudaTensor *grad_output_t_sum = THCudaTensor_newWithSize1d(state, nOutputPlane);
    THCudaTensor_sum(state, grad_output_t_sum, grad_output_t, 1, 0);
    THCudaTensor_cadd(state, grad_bias, grad_bias, 1.0, grad_output_t_sum);

    THCudaTensor_free(state, img_t);
    THCudaTensor_free(state, seg_t);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_img_t);
    THCudaTensor_free(state, grad_seg_t);
    THCudaTensor_free(state, buffer);
    THCudaTensor_free(state, seg_t_expand);
    THCudaTensor_free(state, fgrad_img_t);
    THCudaTensor_free(state, img_cols_t);
    THCudaTensor_free(state, img_cols_t_trans);
    THCudaTensor_free(state, grad_output_t);
    THCudaTensor_free(state, grad_output_t_sum);
  }

  return 1;
}

