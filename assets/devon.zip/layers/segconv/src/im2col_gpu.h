#ifndef IM2COL_GPU_H
#define IM2COL_GPU_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <float.h>

#define CUDA_KERNEL_LOOP(i, n) \
  for (int i = blockIdx.x * blockDim.x + threadIdx.x; i < (n); i += blockDim.x * gridDim.x)

// Use 1024 threads per block, which requires cuda sm_2x or above
const int CUDA_NUM_THREADS = 1024;

// CUDA: number of blocks for threads.
inline int GET_BLOCKS(const int N)
{
  return (N + CUDA_NUM_THREADS - 1) / CUDA_NUM_THREADS;
}


void im2col_cuda(cudaStream_t stream, const float* data_im, const int channels,
            const int height, const int width,
            const int kernel_h, const int kernel_w, const int pad_h,
            const int pad_w, const int stride_h, const int stride_w,
            const int dilation_h, const int dilation_w, float* data_col);

void im2col_flow_cuda(cudaStream_t stream, const float* data_im, const float* data_flow,
            const int channels, const int height, const int width,
            const int kernel_h, const int kernel_w, 
            const int pad_h, const int pad_w, 
            const int stride_h, const int stride_w,
            const int dilation_h, const int dilation_w,
            float* data_col);

void col2im_cuda(cudaStream_t stream, const float* data_col, const int channels,
            const int height, const int width,
            const int output_height, const int output_width,
            const int patch_h, const int patch_w, const int pad_h,
            const int pad_w, const int stride_h, const int stride_w,
            const int dilation_h, const int dilation_w, float* data_im);

void col2im_flow_cuda(cudaStream_t stream, const float* data_im, const float* data_flow, 
            const float* data_fgradInput,
            const int channels, const int height, const int width,
            const int output_height, const int output_width,
            const int kernel_h, const int kernel_w, 
            const int pad_h, const int pad_w, 
            const int stride_h, const int stride_w,
            const int dilation_h, const int dilation_w,
            const int updateGradFlow,
            float* data_gradInput, float* data_gradFlow);

#ifdef __cplusplus
}
#endif

#endif
