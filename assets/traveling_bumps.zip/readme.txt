run ExistenceTestFFT.m in MATLAB to see the traveling bump
