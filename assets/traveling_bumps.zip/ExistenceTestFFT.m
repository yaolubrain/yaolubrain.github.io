clear all;
close all;
nn=50;                       %number of neurons
dt=0.1;                      %temporal resolution
tt=250;                      %display time 
dx=0.5;                      %spatial resolution
A=7.32;                      %amplitude of connectivity funtion
B=2;                         %width of connectivity funtion
a1=3;
a2=0.8;
a3=0.6;
theta=3;

a=15; b=36;
%initial state of excitatory neural field
u1=zeros(nn,nn);
for i=1:nn
    for j=a:b
        u1(i,j)=15*exp(-((dx*(i-5)).^2)/5) - 1 ;
    end
end

%initial state of inhibitory neural field
u2=zeros(nn,nn);
for i=1:nn
    for j=a:b
        u2(i,j)=10*exp(-(dx*(i-3).^2)/5)  ;
    end
end

%weighting function of excitatory neural field
for a=1:nn
    for b=1:nn
        for i=1:nn
            for j=1:nn
                disx=min(dx*abs(i-a),dx*(nn-abs(i-a)));
                disy=min(dx*abs(j-b),dx*(nn-abs(j-b)));
                
                w1(i,j,a,b)=dx^2*A*exp(-(disx.^2+disy.^2)/B);
                
            end
        end
    end
end

%solving equations using Runge-Kutta 4th order method
u1k1=zeros(nn,nn);
u2k1=zeros(nn,nn);
u1k2=zeros(nn,nn);
u2k2=zeros(nn,nn);
u1k3=zeros(nn,nn);
u2k3=zeros(nn,nn);
u1k4=zeros(nn,nn);
u2k4=zeros(nn,nn);
u1k=zeros(nn,nn);
u2k=zeros(nn,nn);


for ti=1
    for i=1:nn
        for j=1:nn
            u1(i,j,ti) = u1(i,j,ti)...
                         + 1/6*dt*( u1k1(i,j,1) + 2*u1k2(i,j,1) + 2*u1k3(i,j,1) + u1k4(i,j,1)  );
            
            u2(i,j,ti) = u2(i,j,ti)...
                         + 1/6*dt*( u2k1(i,j,1) + 2*u2k2(i,j,1) + 2*u2k3(i,j,1) + u2k4(i,j,1)  );   
        end 
    end
    for i=1:nn
        weight(:,i)=sum(ifft(fft(w1(:,:,1,i)).*fft(f(u1(:,:,ti)-theta)))');
    end
    for i=1:nn
        for j=1:nn            
            u1k1(i,j,1) = -u1(i,j,ti) + weight(i,j) - a1*u2(i,j,ti);  
            u2k1(i,j,1) = -a2*u2(i,j,ti) + a3*u1(i,j,ti) ;
         end 
    end         
    for i=1:nn
        for j=1:nn     
            u1k(i,j,1)  =  u1(i,j,ti) + 1/2*dt*u1k1(i,j,1);   
            u2k(i,j,1)  =  u2(i,j,ti) + 1/2*dt*u2k1(i,j,1);
        end 
    end         
    for i=1:nn
        for j=1:nn        
            u1k2(i,j,1) = -u1k(i,j,1) + weight(i,j) - a1*u2k(i,j,1);
            u2k2(i,j,1) = -a2*u2k(i,j,1) + a3*u1k(i,j,1) ;
         end 
    end
    for i=1:nn
        for j=1:nn   
            u1k(i,j,1)  =  u1(i,j,ti) + 1/2*dt*u1k2(i,j,1);
            u2k(i,j,1)  =  u2(i,j,ti) + 1/2*dt*u2k2(i,j,1);  
        end 
    end
    for i=1:nn
        for j=1:nn
            u1k3(i,j,1) = -u1k(i,j,1) + weight(i,j) - a1*u2k(i,j,1);
            u2k3(i,j,1) = -a2*u2k(i,j,1) + a3*u1k(i,j,1) ;    
        end 
    end 
    for i=1:nn
        for j=1:nn    
            u1k(i,j,1)  =  u1(i,j,ti) + dt*u1k3(i,j,1);
            u2k(i,j,1)  =  u2(i,j,ti) + dt*u2k3(i,j,1); 
        end 
    end 
    for i=1:nn
        for j=1:nn
            u1k4(i,j,ti) = -u1k(i,j,ti) + weight(i,j) - a1*u2k(i,j,ti);
            u2k4(i,j,ti) = -a2*u2k(i,j,ti) + a3*u1k(i,j,ti) ;     
        end 
    end
end            
%%%%%%%%%%%%%%%%%%%%
for ti=1:tt
    for i=1:nn
        for j=1:nn
            u1(i,j,ti+1) = u1(i,j,ti)...
                         + 1/6*dt*( u1k1(i,j,1) + 2*u1k2(i,j,1) + 2*u1k3(i,j,1) + u1k4(i,j,1)  );
            
            u2(i,j,ti+1) = u2(i,j,ti)...
                         + 1/6*dt*( u2k1(i,j,1) + 2*u2k2(i,j,1) + 2*u2k3(i,j,1) + u2k4(i,j,1)  );   
        end 
    end
    for i=1:nn
        weight(:,i)=sum(ifft(fft(w1(:,:,1,i)).*fft(f(u1(:,:,ti+1)-theta)))');
    end
    for i=1:nn
        for j=1:nn          
            u1k1(i,j,2) = -u1(i,j,ti+1) + weight(i,j) - a1*u2(i,j,ti+1);  
            u2k1(i,j,2) = -a2*u2(i,j,ti+1) + a3*u1(i,j,ti+1) ;
        end 
    end
    for i=1:nn
        for j=1:nn
            u1k(i,j,2)  =  u1(i,j,ti+1) + 1/2*dt*u1k1(i,j,2);   
            u2k(i,j,2)  =  u2(i,j,ti+1) + 1/2*dt*u2k1(i,j,2); 
        end 
    end
    for i=1:nn
        for j=1:nn     
            u1k2(i,j,2) = -u1k(i,j,2) + weight(i,j) - a1*u2k(i,j,2);
            u2k2(i,j,2) = -a2*u2k(i,j,2) + a3*u1k(i,j,2) ;
        end 
    end 
    for i=1:nn
        for j=1:nn 
            u1k(i,j,2)  =  u1(i,j,ti+1) + 1/2*dt*u1k2(i,j,2);
            u2k(i,j,2)  =  u2(i,j,ti+1) + 1/2*dt*u2k2(i,j,2);  
        end 
    end 
    for i=1:nn
        for j=1:nn    
            u1k3(i,j,2) = -u1k(i,j,2) + weight(i,j) - a1*u2k(i,j,2);
            u2k3(i,j,2) = -a2*u2k(i,j,2) + a3*u1k(i,j,2);
        end 
    end 
    for i=1:nn
        for j=1:nn    
            u1k(i,j,2)  =  u1(i,j,ti+1) + dt*u1k3(i,j,2);
            u2k(i,j,2)  =  u2(i,j,ti+1) + dt*u2k3(i,j,2); 
        end 
    end 
    for i=1:nn
        for j=1:nn
            u1k4(i,j,2) = -u1k(i,j,2) + weight(i,j) - a1*u2k(i,j,2);
            u2k4(i,j,2) = -a2*u2k(i,j,2) + a3*u1k(i,j,2) ;     
            
            u1k1(i,j,1) = u1k1(i,j,2);
            u2k1(i,j,1) = u2k1(i,j,2);
      
            u1k2(i,j,1) = u1k2(i,j,2);
            u2k2(i,j,1) = u2k2(i,j,2);
            
            u1k3(i,j,1) = u1k3(i,j,2);
            u2k3(i,j,1) = u2k3(i,j,2);
            
            u1k4(i,j,1) = u1k4(i,j,2);
            u2k4(i,j,1) = u2k4(i,j,2);
        end 
    end
    ti
end            

%display
for ti=1:tt
    surf(u1(:,:,ti),'EdgeColor','none')
    caxis([-10 20])
    axis([1,nn,1,nn,-20,30])
    view(90,90)
    pause(0.01)
end