clear all
n=8;
f=rand(n,n);
for i=1:n
    for j=1:n
        disx=min(abs(i-1),n-abs(i-1));
        disy=min(abs(j-1),n-abs(j-1));
        w(i,j)=exp(-disx.^2-disy.^2);
    end
end
for i=1:n
    for j=1:n
        for a=1:n
            for b=1:n
                disx=min(abs(i-a),(n-abs(i-a)));
                disy=min(abs(j-b),(n-abs(j-b)));
                
                W(i,j,a,b)=exp(-disx.^2-disy.^2);
            end
        end
    end
end
for i=1:n
    for j=1:n
        u(i,j)=sum(sum(W(:,:,i,j).*f));
    end
end
for i=1:n
    v(:,i)=sum(ifft(fft(W(:,:,1,i)).*fft(f))');
end

u
v
u-v