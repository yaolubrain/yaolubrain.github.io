function y = f(x)

y = 1./ (1 + exp(-2*(x-4)));