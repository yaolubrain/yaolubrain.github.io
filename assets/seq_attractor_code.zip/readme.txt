1) The code to reproduce
Figure 2, failure_cases.m
Figure 4, rand_proj.m
Figure 5, two_layer_learn_periodic.m
Figure 6, two_layer_learn_random.m
Figure 7 and 8, width_two_layer.m, bar_two_layers.m, bar_width_two_layers.m
Figure 9, silhouette.m
Figure 10, moving_mnist.m, retrieval_mnist.m
Figure 11, plot_err_two_layer.m
Figure 12, silhouette_bin.py, silhouette_tanh.py, moving_mnist_bin.py, moving_mnist_tanh.py
Appendix B, mhn_mnist.m, mhn_silhouette.m


2) The silhouette sequence dataset (OU-ISIR gait database large population) can be found in
http://www.am.sanken.osaka-u.ac.jp/BiometricDB/GaitLP.html

We used its sample dataset
http://www.am.sanken.osaka-u.ac.jp/BiometricDB/dataset/GaitLP/OULP_SilhouetteSample.zip


3) The handwriting sequence dataset (Moving MNIST) can be downloaded in 
https://www.cs.toronto.edu/~nitish/unsupervised_video/

We converted the .npy file to .h5 file using npy2h5.py in the folder.

