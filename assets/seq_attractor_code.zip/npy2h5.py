import numpy as np
import h5py

A = np.load('mnist_test_seq.npy')
print(A.shape)

f = h5py.File('mnist_test_seq.h5', 'w')
f.create_dataset('data', data=A)
f.close()
