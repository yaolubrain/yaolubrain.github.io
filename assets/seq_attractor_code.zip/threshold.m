function y = threshold(x)

y = single(zeros(size(x)));
y(x>0) = 1;
