clear all
close all

% N = 30;
% P = 1000;
% 
% 
% X = sign(randn(N,P));


T = 136 - 34 + 1;
N = 128*88;
M = 200;

epochs = 100;

X = single(zeros(N,T));

for i = 34:136
    I = imread(sprintf('OULP_SilhouetteSample/%08d.png', i));        
    X(:,i-34+1) = 2*sign(single(reshape(I,[N 1]))) - 1;
end

S = zeros(N,T);
S(:,1) = X(:,1);
rp = randperm(N);
for i = 1:2000
    S(rp(i),1) = -S(rp(i),1);
end



for t = 1:T-1
    
    m = zeros(N,T-1);
%     for p = 1:P-1
%         for i = 1:N
%             m(i,p) = 1/(N-1) * (dot(X(:,p), S(:,t)) - X(i,p)*S(i,t));
%         end
%     end
%     
    m = 1/(N-1) * (repmat(X(:,1:T-1)' * S(:,t), [1 N])' - bsxfun(@times, X(:,1:T-1), S(:,t)));
     
%     m = 1/(N-1) * bsxfun(@times, X(:,1:P-1), S(:,t));
    f = m.^30;
%     f = exp(m);
    S(:,t+1) = sign( sum(X(:,2:T) .* f, 2) );
end


sum(sum(abs(S(:,end)-X(:,end))))

figure;
colormap(gray)
for t = 1:T
    I = reshape(S(:,t), [128 88]);
    imagesc(I, [-1 1]); 
    axis equal; axis off;
    pause(0.1)
%     fname = sprintf('silhouette_%d_one.pdf', t);
%     export_fig(fname,  '-pdf')
end

% 