function P = DSPFP(A1,A2,K)

n1 = size(A1,1);
n2 = size(A2,1);
X = ones(n1,n2)/(n1*n2);
% X = ones(n1,n2);

ep=100;
index=1;
maxN=max(n1,n2);
Y=zeros(maxN,maxN);

a = 0.5;
c = 1;

while ep >= 0.01 && index <= 30
    x = X;        
    Y(1:n1,1:n2) = A1*X*A2+c*K;  
    Y = gm_dsn(Y);   
    X = (1-a)*X+a*Y(1:n1,1:n2);
    X = X/(max(max(X)));        
    ep = max(max(abs(x-X)))
    index = index + 1;
end
index
P=dis_greedy(X);