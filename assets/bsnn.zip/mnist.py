import argparse
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from utils import progress_bar
from bsnn import *

class Net(nn.Module):
    def __init__(self):
        super().__init__()

        layers = []

        for i in range(200):
            layers.append(OrthLinear(500, constraint=True, with_bn=False))
            #layers.append(Tanh())
            #layers.append(TanhGPN())
            #layers.append(ReLU())
            #layers.append(ReLUGPN())
            #layers.append(LeakyReLU())
            #layers.append(LeakyReLUGPN())
            #layers.append(ELU())
            #layers.append(ELUGPN())
            #layers.append(SELU())
            #layers.append(SELUGPN())
            #layers.append(GELU())
            layers.append(GELUGPN())

        self.fc1 = nn.Linear(28*28, 500)
        #self.act = Tanh()
        #self.act = TanhGPN()
        #self.act = ReLU()
        #self.act = ReLUGPN()
        #self.act = LeakyReLU()
        #self.act = LeakyReLUGPN()
        #self.act = ELU()
        #self.act = ELUGPN()
        #self.act = SELU()
        #self.act = SELUGPN()
        #self.act = GELU()
        self.act = GELUGPN()
        self.fcs = nn.Sequential(*layers)
        self.out = nn.Linear(500, 10)

    def forward(self, x):
        x = x.view(-1, 28*28)
        x = self.fc1(x)
        x = self.act(x)
        x = self.fcs(x)
        x = self.out(x)
        return F.log_softmax(x, dim=1)
    

def train(args, model, device, train_loader, optimizer, epoch):
    print('\nEpoch: %d' % epoch)
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)

        optimizer.zero_grad()
        output = model(data)
        loss = F.nll_loss(output, target)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = output.max(1)

        total += target.size(0)
        correct += predicted.eq(target).sum().item()

        progress_bar(batch_idx, len(train_loader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
            % (train_loss/(batch_idx+1), 100.*correct/total, correct, total))

        grad_max = 0.0
        grad_min = float('inf')

        for p in model.parameters():
            if p.dim() == 2 and p.size(0) == p.size(1):
                grad_max = max(grad_max, p.grad.norm().item())
                grad_min = min(grad_min, p.grad.norm().item())

        fname = 'log/' + args.tag + '_mnist_grad_norm.txt'
        with open(fname, 'a') as f:
            printed_line = f'{grad_max / grad_min:.4f}\n'
            f.write(printed_line)

    return 100. * correct / len(train_loader.dataset)


def test(args, model, device, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.nll_loss(output, target).item() # sum up batch loss
            pred = output.argmax(dim=1, keepdim=True) # get the index of the max log-probability
            correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader.dataset)

    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))

    return 100. * correct / len(test_loader.dataset)


parser = argparse.ArgumentParser(description='MNIST')
parser.add_argument('--lr', type=float)
parser.add_argument('--tag', type=str)
args = parser.parse_args()


train_loader = torch.utils.data.DataLoader(
    torchvision.datasets.MNIST('../data', train=True, download=True,
                   transform=transforms.Compose([
                       transforms.ToTensor(),
                       transforms.Normalize((0.1307,), (0.3081,))
                   ])),
    batch_size=64, shuffle=True, num_workers=2)

test_loader = torch.utils.data.DataLoader(
    torchvision.datasets.MNIST('../data', train=False, transform=transforms.Compose([
                        transforms.ToTensor(),
                        transforms.Normalize((0.1307,), (0.3081,))
                   ])),
    batch_size=100, shuffle=True, num_workers=2)

device = torch.device("cuda")

model = Net().to(device)
def weights_init(m):
    if isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight.data)
model.apply(weights_init)

optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=0.5)

fname = 'log/' + args.tag + '_mnist_grad_norm.txt'
open(fname, 'w').close()

fname = 'log/' + args.tag + '_mnist.txt'
open(fname, 'w').close()

for epoch in range(50):
    train_acc = train(args, model, device, train_loader, optimizer, epoch)
    test_acc = test(args, model, device, test_loader)

    with open(fname, 'a') as f:
        printed_line = f'{train_acc:.4f} {test_acc:.4f}\n'
        f.write(printed_line)
