import argparse
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from utils import progress_bar
from bsnn import *

class Net(nn.Module):
    def __init__(self):
        super().__init__()

        layers = []

        for i in range(200):
            layers.append(OrthLinear(500, constraint=True, with_bn=False))
            #layers.append(Tanh())
            #layers.append(TanhGPN())
            #layers.append(ReLU())
            #layers.append(ReLUGPN())
            #layers.append(LeakyReLU())
            #layers.append(LeakyReLUGPN())
            #layers.append(ELU())
            #layers.append(ELUGPN())
            #layers.append(SELU())
            #layers.append(SELUGPN())
            #layers.append(GELU())
            layers.append(GELUGPN())

        self.fc1 = nn.Linear(32*32*3, 500)
        #self.act = Tanh()
        #self.act = TanhGPN()
        #self.act = ReLU()
        #self.act = ReLUGPN()
        #self.act = LeakyReLU()
        #self.act = LeakyReLUGPN()
        #self.act = ELU()
        #self.act = ELUGPN()
        #self.act = SELU()
        #self.act = SELUGPN()
        #self.act = GELU()
        self.act = GELUGPN()

        self.fcs = nn.Sequential(*layers)
        self.out = nn.Linear(500, 10)

    def forward(self, x):
        x = x.view(-1, 32*32*3)
        x = self.act(self.fc1(x))
        x = self.fcs(x)
        x = self.out(x)
        return F.log_softmax(x, dim=1)


def train(epoch):
    print('\nEpoch: %d' % epoch)
    model.train()
    train_loss = 0
    correct = 0
    total = 0

    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)

        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
            % (train_loss/(batch_idx+1), 100.*correct/total, correct, total))

        grad_max = 0.0
        grad_min = float('inf')

        for p in model.parameters():
            if p.dim() == 2 and p.size(0) == p.size(1):
                grad_max = max(grad_max, p.grad.norm().item())
                grad_min = min(grad_min, p.grad.norm().item())

        fname = 'log/' + args.tag + '_cifar10_grad_norm.txt'
        with open(fname, 'a') as f:
            printed_line = f'{grad_max / grad_min:.4f}\n'
            f.write(printed_line)

    return 100 * correct / total

def test(epoch):
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

    return correct / total


parser = argparse.ArgumentParser(description='CIFAR-10')
parser.add_argument('--lr', type=float)
parser.add_argument('--tag', type=str)
args = parser.parse_args()

start_epoch = 0  # start from epoch 0 or last checkpoint epoch

transform_train = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=64, shuffle=True, num_workers=2)

testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=2)

classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')


device = torch.device("cuda")

model = Net().to(device)

def weight_init(m):
    if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight.data)
model.apply(weight_init)        

criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=0.5)

fname = 'log/' + args.tag + '_cifar10_grad_norm.txt'
open(fname, 'w').close()

fname = 'log/' + args.tag + '_cifar10.txt'
open(fname, 'w').close()

for epoch in range(100):
    train_acc = train(epoch)
    test_acc = test(epoch)

    with open(fname, 'a') as f:

        printed_line = f'{train_acc:.4f} {test_acc:.4f}\n'
        f.write(printed_line)
