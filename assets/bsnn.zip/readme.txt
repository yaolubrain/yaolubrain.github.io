To compute the constants a and b for Gaussian-Poincare normalization, run
compute_gpn_constants.m
in MATLAB

For experiments on synthetic data, run 
syntheic.m
in MATLAB

For experiments on MNIST, run for example:
python mnist.py --tag tanh_gpn --lr 1e-4

For experiments on CIFAR-10, run for example:
python cifar10.py --tag tanh_gpn --lr 1e-4
