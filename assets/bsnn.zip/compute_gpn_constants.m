clear all;
close all;

%% Tanh

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1 - tanh(x).^2 ).^2;
q = integral(fun,-Inf,Inf);
a = 1 / sqrt(q);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( tanh(x) );
E1 = integral(fun,-Inf,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( tanh(x) ).^2;
E2 = integral(fun,-Inf,Inf);

b = -a*E1 + sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]


%% ReLU

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1 ).^2;
q = integral(fun,0,Inf);
a = 1 / sqrt(q);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x );
E1 = integral(fun,0,Inf);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x ).^2;
E2 = integral(fun,0,Inf);

b = -a*E1 + sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]


%% LeakyReLU

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1 ).^2;
q1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 0.01 ).^2;
q2 = integral(fun,-Inf,0);

q = q1 + q2;
a = 1 / sqrt(q);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x );
E1_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 0.01*x );
E1_2 = integral(fun,-Inf,0);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x ).^2;
E2_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 0.01*x ).^2;
E2_2 = integral(fun,-Inf,0);

E1 = E1_1 + E1_2;
E2 = E2_1 + E2_2;

b = -a*E1 + sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]


%% ELU

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1 ).^2;
q1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( exp(x) ).^2;
q2 = integral(fun,-Inf,0);

q = q1 + q2;
a = 1 / sqrt(q);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x );
E1_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( exp(x)-1 );
E1_2 = integral(fun,-Inf,0);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x ).^2;
E2_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( exp(x)-1 ).^2;
E2_2 = integral(fun,-Inf,0);

E1 = E1_1 + E1_2;
E2 = E2_1 + E2_2;

b = -a*E1 + sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]


%% SELU

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507 ).^2;
q1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507*1.6733*exp(x) ).^2;
q2 = integral(fun,-Inf,0);

q = q1 + q2;
a = 1 / sqrt(q);


fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507*x );
E1_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507*1.6733*(exp(x)-1) );
E1_2 = integral(fun,-Inf,0);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507*x ).^2;
E2_1 = integral(fun,0,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1.0507*1.6733*(exp(x)-1) ).^2;
E2_2 = integral(fun,-Inf,0);

E1 = E1_1 + E1_2;
E2 = E2_1 + E2_2;

b = -a*E1 + sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]


%% GELU

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( 1./(1+exp(-1.702*x)) + x.*1.702*1./(1+exp(-1.702*x)).*(1-1./(1+exp(-1.702*x))) ).^2;
q = integral(fun,-Inf,Inf);
a = 1 / sqrt(q);

fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x .* 1./(1+exp(-1.702*x)) );
E1 = integral(fun,-Inf,Inf);
fun = @(x) 1./sqrt(2*pi) * exp(-x.^2/2) .* ( x .* 1./(1+exp(-1.702*x)) ).^2;
E2 = integral(fun,-Inf,Inf);

b = -a*E1 - sqrt(a^2*E1^2 - (a^2*E2 - 1));

[a b]