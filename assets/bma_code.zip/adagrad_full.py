import torch
from torch.optim.optimizer import Optimizer


class AdaGradFull(Optimizer):

    def __init__(self, params, lr=1e-2, lr_decay=0, weight_decay=0):
        defaults = dict(lr=lr, lr_decay=lr_decay, weight_decay=weight_decay)
        super(AdaGradFull, self).__init__(params, defaults)

        self.lr = lr

        self.num_groups = 0
        self.num_params = 0
        self.group_size = []
        self.params = []
        self.momentum = []
        for group in self.param_groups:
             for p in group['params']:
                 if p.requires_grad:
                     self.num_groups += 1
                     self.num_params += p.nelement()
                     self.group_size.append(p.nelement())
                     self.params.append(p)
                     self.momentum.append(torch.zeros_like(p.data))

        self.G = torch.zeros(self.num_params, self.num_params)

        if self.params[0].is_cuda:
            self.G = self.G.cuda()


    def step(self, closure=None):
        loss = None

        g = torch.Tensor(self.num_params)
        if self.params[0].is_cuda:
            g = g.cuda()

        index = 0
        for l, p in enumerate(self.params):
            num_param = p.nelement()
            g[index:index+num_param] = p.grad.data.view(-1)
            index += num_param

        self.G.addr_(g, g)
        e, R = torch.symeig(self.G, eigenvectors=True)
        E = e.clamp(min=1e-8).pow(-1/2).diag()

        G_inv_sqrt = R @ E @ R.t()

        g = G_inv_sqrt @ g

        index = 0
        for l, p in enumerate(self.params):
            num_param = p.nelement()
            g_p = g[index:index+num_param].view_as(p.data)
            p.data.add_(-self.lr * g_p)
            index += num_param

        return loss
