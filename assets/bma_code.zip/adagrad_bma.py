import math
import torch
from torch.optim.optimizer import Optimizer


class AdaGradBMA(Optimizer):

    def __init__(self, params, lr=1e-2, lr_decay=0, weight_decay=0):
        defaults = dict(lr=lr, lr_decay=lr_decay, weight_decay=weight_decay)
        super().__init__(params, defaults)

        self.lr = lr

        self.num_groups = 0
        self.group_size = []
        self.params = []
        self.momentum = []
        for group in self.param_groups:
             for p in group['params']:
                 if p.requires_grad:
                     self.num_groups += 1
                     self.group_size.append(p.nelement())
                     self.params.append(p)
                     self.momentum.append(torch.zeros_like(p.data))

        self.U = torch.zeros(self.num_groups, self.num_groups)
        self.V = torch.zeros(self.num_groups, self.num_groups)

        s = torch.Tensor(self.group_size)
        self.S = s.diag()
        self.S_inv = s.reciprocal().diag()
        self.S_sqrt = s.sqrt().diag()
        self.S_inv_sqrt = s.pow(-1/2).diag()
        self.W = torch.reciprocal(torch.ger(s,s) - self.S)

        for p in self.params:
            if p.is_cuda:
                 self.U = self.U.cuda()
                 self.V = self.V.cuda()
                 self.W = self.W.cuda()
                 self.S = self.S.cuda()
                 self.S_sqrt = self.S_sqrt.cuda()
                 self.S_inv = self.S_inv.cuda()
                 self.S_inv_sqrt = self.S_inv_sqrt.cuda()


    def step(self, closure=None):
        loss = None

        u = torch.Tensor(len(self.params))
        v = torch.Tensor(len(self.params))
        for l, p in enumerate(self.params):
            self.momentum[l].add_(p.grad.data.pow(2))
            u[l] = p.grad.data.sum() 
            v[l] = torch.pow(self.momentum[l] + 1e-10, 1/2).sum()

        if self.params[0].is_cuda:
            u = u.cuda()
            v = v.cuda()

        self.U.addr_(u, u)

        B = self.U - self.U.diag().diag()
        B.div_(torch.ger(v,v))
        L = torch.eye(len(self.params)).cuda()
        D = L + B

        e, R = torch.symeig(D, eigenvectors=True)
        E = e.clamp(min=1e-10).pow(-1/2).diag()

        D = R @ E @ R.t() - L


        D = self.S_inv_sqrt @ D @ self.S_inv_sqrt
        Du = D @ u.view(-1,1)


        
        for l, p in enumerate(self.params):
            p.grad.data.mul_(torch.pow(self.momentum[l] + 1e-10, -1/4))
            p.grad.data.add_(Du[l])
            p.grad.data.mul_(torch.pow(self.momentum[l] + 1e-10, -1/4))

            p.data.add_(-self.lr * p.grad.data)           

        return loss
